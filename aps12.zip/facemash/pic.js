<!--
var rand=Math.round(Math.random()*10);
var img=new Array(1);
img[0]="black";
img[1]="blue";
img[2]="gray";
img[3]="lime";
img[4]="orange"
img[5]="pink"
img[6]="purple"
img[7]="red"
img[8]="skyblue"
img[9]="yellow"
document.write(img[rand]);
-->