<!DOCTYPE html>
<html>
<head><meta charset="utf-8">
<title>Pranav Sanghvi</title>
</head>

<body>
    <div align="center"
        <text size='7'>Welcome to the Pranav Sanghvi website!</text>
        <br />
        <!--<img width="25%" height="25%" src="img.jpg">-->
    </div>
    
</body>
</html>
