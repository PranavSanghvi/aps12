<!DOCTYPE html>
<html>
<head>
    <title>Pranav Sanghvi</title>
    <!-- HTML meta refresh URL redirection -->
    <meta http-equiv="refresh" content="0; url=l.php">
</head>
Loading...
</html>