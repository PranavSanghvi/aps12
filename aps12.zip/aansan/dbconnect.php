<?php
$con = mysqli_connect("fdb16.awardspace.net", "2394712_db", "E3hzQFiS", "2394712_db") or die("Database Connection Error".mysqli_error($con));
?>