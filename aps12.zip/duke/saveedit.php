<?php
require_once("dbconnect.php");
$db_handle = new DBController();
$result = $db_handle->executeUpdate("UPDATE duke set " . $_POST["column"] . " = '".$_POST["editval"]."' WHERE  id=".$_POST["id"]);
?>