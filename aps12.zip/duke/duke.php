<?php
session_start();
include_once 'dbconnect.php';

//require_once("dbcontroller.php");
$db_handle = new DBController();
$sql = "SELECT * from duke";
$faq = $db_handle->runQuery($sql);

?>

<!DOCTYPE html>
<html>
<head>
    <title>Duke</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport" >
	
	<style>
			.tbl-qa{width: 100%;font-size:0.9em;background-color: #FDFDFD;}
			.tbl-qa th.table-header {padding: 5px;text-align: left;padding:10px;background-color: #f5f5f5;border-bottom:1pt solid black;}
			.tbl-qa .table-row td {padding:10px;}
			.tbl-qa td.columnodd {background-color: #F5F5F5;}
	</style>
	<script src="http://code.jquery.com/jquery-1.10.2.js"></script>
		<script>
		function showEdit(editableObj) {
			$(editableObj).css("background",""); //#FFF in ""
		} 
		
		function saveToDatabase(editableObj,column,id) {
			$(editableObj).css("background"," url(loaderIcon.gif) no-repeat right"); //#FFF before "url"
			$.ajax({
				url: "saveedit.php",
				type: "POST",
				data:'column='+column+'&editval='+editableObj.innerHTML+'&id='+id,
				success: function(data){
					$(editableObj).css("background",""); //#FDFDFD in ""
				}        
		   });
		}
		</script>
	
    <link rel="stylesheet" href="css/bootstrap.min.css" type="text/css" />
</head>
<body>

<nav class="navbar navbar-default" role="navigation">
    <div class="container-fluid">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar1">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a class="navbar-brand" href="index.php">DUKE</a>
        </div>
        <div class="collapse navbar-collapse" id="navbar1">
            <ul class="nav navbar-nav navbar-left">
                <?php if (isset($_SESSION['user_id'])) { ?>
                <li class="active"><a href="duke.php">Duke</a></li>
                <?php } ?>
            </ul>
            <ul class="nav navbar-nav navbar-right">
                <?php if (isset($_SESSION['user_id'])) { ?>
                <li><p class="navbar-text">Signed in as <b><?php echo $_SESSION['user_name']; ?></b></p></li>
                <li><a href="account.php">My Account</a></li>
                <li><a href="logout.php">Log Out</a></li>
                <?php } else { ?>
                <li><a href="login.php">Login</a></li>
                <!--<li><a href="register.php">Sign Up</a></li>-->
                <?php } ?>
            </ul>
        </div>
    </div>
</nav>

<?php // if (isset($_SESSION['user_id'])) { ?>
    <div class="container">
		<div class="row">
			<div class="col-sm-8 col-md-12 ">
				<table class="tbl-qa">
					<thead>
						<tr>
							<th class="table-header" width="3%"></th>
							<th class="table-header" width="25%"></th>
							<th class="table-header" width="4%">PMH</th>
							<th class="table-header" width="4%">C</th>
							<th class="table-header" width="4%">0</th>
							<th class="table-header" width="4%">2</th>
							<th class="table-header" width="4%">4</th>
							<th class="table-header" width="4%">8</th>
							<th class="table-header" width="4%">12</th>
							<th class="table-header" width="4%">16</th>
							<th class="table-header" width="4%">20</th>
							<th class="table-header" width="4%">24</th>
							<th class="table-header" width="4%">26</th>
							<th class="table-header" width="4%">28</th>
							<th class="table-header" width="4%">36</th>
							<th class="table-header" width="4%">48</th>
							<th class="table-header" width="4%">FU</th>
							<th class="table-header" width="4%">U</th>
							<th class="table-header" width="4%">U</th>
							<th class="table-header" width="4%">U</th>
						</tr>
					</thead>
					<tbody>
						<?php
							foreach($faq as $k=>$v) {
						?>
						<tr class="table-row">
							<td tabindex="1" class="columnodd"><?php echo $k+1; ?></td>
							<td tabindex="2" contenteditable="false" onBlur="saveToDatabase(this,'category','<?php echo $faq[$k]["id"]; ?>')" onClick="showEdit(this);"><?php echo $faq[$k]["category"]; ?></td>
							<td tabindex="3" class="columnodd" contenteditable="true" onBlur="saveToDatabase(this,'PMH','<?php echo $faq[$k]["id"]; ?>')" onClick="showEdit(this);"><?php echo $faq[$k]["PMH"]; ?></td>
							<td tabindex="4" contenteditable="true" onBlur="saveToDatabase(this,'C','<?php echo $faq[$k]["id"]; ?>')" onClick="showEdit(this);"><?php echo $faq[$k]["C"]; ?></td>
							<td tabindex="5" class="columnodd" contenteditable="true" onBlur="saveToDatabase(this,'N0','<?php echo $faq[$k]["id"]; ?>')" onClick="showEdit(this);"><?php echo $faq[$k]["N0"]; ?></td>
							<td tabindex="6" contenteditable="true" onBlur="saveToDatabase(this,'N2','<?php echo $faq[$k]["id"]; ?>')" onClick="showEdit(this);"><?php echo $faq[$k]["N2"]; ?></td>
							<td tabindex="7" class="columnodd" contenteditable="true" onBlur="saveToDatabase(this,'N4','<?php echo $faq[$k]["id"]; ?>')" onClick="showEdit(this);"><?php echo $faq[$k]["N4"]; ?></td>
							<td tabindex="8" contenteditable="true" onBlur="saveToDatabase(this,'N8','<?php echo $faq[$k]["id"]; ?>')" onClick="showEdit(this);"><?php echo $faq[$k]["N8"]; ?></td>
							<td tabindex="9" class="columnodd" contenteditable="true" onBlur="saveToDatabase(this,'N12','<?php echo $faq[$k]["id"]; ?>')" onClick="showEdit(this);"><?php echo $faq[$k]["N12"]; ?></td>
							<td tabindex="10" contenteditable="true" onBlur="saveToDatabase(this,'N16','<?php echo $faq[$k]["id"]; ?>')" onClick="showEdit(this);"><?php echo $faq[$k]["N16"]; ?></td>
							<td tabindex="11" class="columnodd" contenteditable="true" onBlur="saveToDatabase(this,'N20','<?php echo $faq[$k]["id"]; ?>')" onClick="showEdit(this);"><?php echo $faq[$k]["N20"]; ?></td>
							<td tabindex="12" contenteditable="true" onBlur="saveToDatabase(this,'N24','<?php echo $faq[$k]["id"]; ?>')" onClick="showEdit(this);"><?php echo $faq[$k]["N24"]; ?></td>
							<td tabindex="13" class="columnodd" contenteditable="true" onBlur="saveToDatabase(this,'N26','<?php echo $faq[$k]["id"]; ?>')" onClick="showEdit(this);"><?php echo $faq[$k]["N26"]; ?></td>
							<td tabindex="14" contenteditable="true" onBlur="saveToDatabase(this,'N28','<?php echo $faq[$k]["id"]; ?>')" onClick="showEdit(this);"><?php echo $faq[$k]["N28"]; ?></td>
							<td tabindex="15" class="columnodd" contenteditable="true" onBlur="saveToDatabase(this,'N36','<?php echo $faq[$k]["id"]; ?>')" onClick="showEdit(this);"><?php echo $faq[$k]["N36"]; ?></td>
							<td tabindex="16" contenteditable="true" onBlur="saveToDatabase(this,'N48','<?php echo $faq[$k]["id"]; ?>')" onClick="showEdit(this);"><?php echo $faq[$k]["N48"]; ?></td>
							<td tabindex="17" class="columnodd" contenteditable="true" onBlur="saveToDatabase(this,'FU','<?php echo $faq[$k]["id"]; ?>')" onClick="showEdit(this);"><?php echo $faq[$k]["FU"]; ?></td>
							<td tabindex="18" contenteditable="true" onBlur="saveToDatabase(this,'U1','<?php echo $faq[$k]["id"]; ?>')" onClick="showEdit(this);"><?php echo $faq[$k]["U1"]; ?></td>
							<td tabindex="19" class="columnodd" contenteditable="true" onBlur="saveToDatabase(this,'U2','<?php echo $faq[$k]["id"]; ?>')" onClick="showEdit(this);"><?php echo $faq[$k]["U2"]; ?></td>
							<td tabindex="20" contenteditable="true" onBlur="saveToDatabase(this,'U3','<?php echo $faq[$k]["id"]; ?>')" onClick="showEdit(this);"><?php echo $faq[$k]["U3"]; ?></td>
						</tr>
						<?php
							}
						?>
					</tbody>
				</table>
				<!--<table class="tbl-qa">
					<tbody>
						<tr class="table-row">
							<td class="columnodd" width="3%"></td>
							<td width="22.9%"></td>
							<td class="columnodd" width="4%"><button type="button">R</button></td>
							<td width="4%"><button type="button">R</button></td>
							<td class="columnodd" width="4%"><button type="button">R</button></td>
							<td width="4%"><button type="button">R</button></td>
							<td class="columnodd" width="4%"><button type="button">R</button></td>
							<td width="4%"><button type="button">R</button></td>
							<td class="columnodd" width="4%"><button type="button">R</button></td>
							<td width="4%"><button type="button">R</button></td>
							<td class="columnodd" width="4%"><button type="button">R</button></td>
							<td width="4%"><button type="button">R</button></td>
							<td class="columnodd" width="4%"><button type="button">R</button></td>
							<td width="4%"><button type="button">R</button></td>
							<td class="columnodd" width="4%"><button type="button">R</button></td>
							<td width="4%"><button type="button">R</button></td>
							<td class="columnodd" width="4%"><button type="button">R</button></td>
							<td width="4%"><button type="button">R</button></td>
							<td class="columnodd" width="4%"><button type="button">R</button></td>
							<td width="4%"><button type="button">R</button></td>
							<td class="columnodd" width="4%"><button type="button">R</button></td>
						</tr>
					</tbody>
				</table>-->
			</div>
		</div>
    </div>
	<br>
<?php // } ?>

<script src="js/jquery-1.10.2.js"></script>
<script src="js/bootstrap.min.js"></script>
</body>
</html>