<?php
session_start();
include_once 'dbconnect.php';

if (is_null($_SESSION['user_id'])) {
    header("Location: index.php");
}

if ($_SESSION['user_rank'] == "Student") {
	header("Location: index.php");
}

$db_handle = new DBController();
$sql = "SELECT * from neettemplate";
$faq = $db_handle->runQuery($sql);
$username = "neettemplate";
$conn = $db_handle->connectDB();

$allusers = "SELECT * from students where rank = 'Student'";
$userlist = $db_handle->runQuery($allusers);

$edit = true;

if (isset($_POST['choose'])) {
    $username = mysqli_real_escape_string($conn, $_POST['choosestudent']);
	$getdata = "SELECT * from " .$username;
	$edit = false;
	if($faq = $db_handle->runQuery($getdata)) {
		$successmsg2 = "Successfully retrieved data!";
	}
	else {
		$errormsg2 = "Retrieval Error: Please try again later";
	}
}

?>

<!DOCTYPE html>
<html>
<head>
    <title>Trackers - NEET Tracker</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport" >
	
	<style>
			.tbl-qa{width: 100%;font-size:0.9em;background-color: #FDFDFD;}
			.tbl-qa th.table-header {padding: 5px;text-align: left;padding:10px;background-color: #f5f5f5;border-bottom:1pt solid black;}
			.tbl-qa .table-row td {padding:10px; border-bottom:2pt solid #FDFDFD;}
			.tbl-qa td.columnodd {background-color: #F5F5F5;}
	</style>
	<script src="http://code.jquery.com/jquery-1.10.2.js"></script>
		<script>
		function showEdit(editableObj) {
			$(editableObj).css("background",""); //#FFF in ""
		} 
		
		function saveToDatabase(editableObj,column,id,table) {
			$(editableObj).css("background"," url(loaderIcon.gif) no-repeat right"); //#FFF before "url"
			$.ajax({
				url: "saveedit.php",
				type: "POST",
				data:'column='+column+'&editval='+editableObj.innerHTML+'&id='+id+'&table='+table,
				success: function(data){
					$(editableObj).css("background",""); //#FDFDFD in ""
				}        
		   });
		}
		
		function activate() {
			$('#choosestudent').one('change', function() {
				$('#choose').prop('disabled', false);
			});
		}
		</script>
	
    <link rel="stylesheet" href="css/bootstrap.min.css" type="text/css" />
</head>
<body>

<nav class="navbar navbar-default" role="navigation">
    <div class="container-fluid">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar1">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a class="navbar-brand" href="index.php">NEET Tracker</a>
        </div>
        <div class="collapse navbar-collapse" id="navbar1">
            <ul class="nav navbar-nav navbar-left">
                <?php if (isset($_SESSION['user_id'])) { ?>
				<?php if ($_SESSION['user_rank'] == "Student") { ?>
                <li class=""><a href="tracker.php">Tracker</a></li>
				<?php } ?>
				<?php if ($_SESSION['user_rank'] == "Admin") { ?>
				<li class=""><a href="trackerkey.php">Key</a></li>
				<li class="active"><a href="trackers.php">Trackers</a></li>
				<li class=""><a href="trackeredit.php">Edit</a></li>
				<li class=""><a href="students.php">Students</a></li>
				<?php } ?>
                <?php } ?>
            </ul>
            <ul class="nav navbar-nav navbar-right">
                <?php if (isset($_SESSION['user_id'])) { ?>
                <li><p class="navbar-text">Signed in as <b><?php echo $_SESSION['user_name']; ?></b></p></li>
                <li><a href="account.php">My Account</a></li>
                <li><a href="logout.php">Log Out</a></li>
                <?php } else { ?>
                <li><a href="login.php">Login</a></li>
                <!--<li><a href="register.php">Sign Up</a></li>-->
                <?php } ?>
            </ul>
        </div>
    </div>
</nav>

<?php if (isset($_SESSION['user_id'])) { ?>
    <div class="container">
		<div class="row">
			<div class="col-sm-8 col-md-10">
				<table class="tbl-qa">
					<thead>
						<tr>
							<!--<th class="table-header" width="12.5%"></th>-->
							<th class="table-header" width="6%">Date</th>
							<th class="table-header" width="5%">Day #</th>
							<th class="table-header" width="20%">Module</th>
							<th class="table-header" width="20%">Tasks</th>
							<th class="table-header" width="4%"># of Hours</th>
							<th class="table-header" width="4%">Status</th>
							<th class="table-header" width="2%"></th>
							<th class="table-header" width="39%" style="max-width:39%">Notes</th>
						</tr>
					</thead>
					<tbody>
						<?php
							foreach($faq as $k=>$v) {
						?>
						<tr class="table-row">
							<!--<td class="columnodd"><?php echo $k+1; ?></td>-->
							<td class="columnodd" contenteditable="<?php echo $edit ?>" onBlur="saveToDatabase(this,'date','<?php echo $faq[$k]["id"]; ?>', '<?php echo $username ?>')" onClick="showEdit(this);"><?php echo $faq[$k]["date"]; ?></td>
							<td contenteditable="<?php echo $edit ?>" onBlur="saveToDatabase(this,'Day','<?php echo $faq[$k]["id"]; ?>', '<?php echo $username ?>')" onClick="showEdit(this);"><?php echo $faq[$k]["Day"]; ?></td>
							<td class="columnodd" contenteditable="<?php echo $edit ?>" onBlur="saveToDatabase(this,'Module','<?php echo $faq[$k]["id"]; ?>', '<?php echo $username ?>')" onClick="showEdit(this);"><?php echo $faq[$k]["Module"]; ?></td>
							<td contenteditable="<?php echo $edit ?>" onBlur="saveToDatabase(this,'Tasks','<?php echo $faq[$k]["id"]; ?>', '<?php echo $username ?>')" onClick="showEdit(this);"><?php echo $faq[$k]["Tasks"]; ?></td>
							<td class="columnodd" contenteditable="<?php echo $edit ?>" onBlur="saveToDatabase(this,'Hours','<?php echo $faq[$k]["id"]; ?>', '<?php echo $username ?>')" onClick="showEdit(this);"><?php echo $faq[$k]["Hours"]; ?></td>
							<td contenteditable="<?php echo $edit ?>" onBlur="saveToDatabase(this,'Status','<?php echo $faq[$k]["id"]; ?>', '<?php echo $username ?>')" onClick="showEdit(this);"><?php echo $faq[$k]["Status"]; ?></td>
							<td contenteditable="false" onBlur="" onClick="">%</td>
							<td class="columnodd" contenteditable="<?php echo $edit ?>" onBlur="saveToDatabase(this,'Notes','<?php echo $faq[$k]["id"]; ?>', '<?php echo $username ?>')" onClick="showEdit(this);"><?php echo $faq[$k]["Notes"]; ?></td>
						</tr>
						<?php
							}
						?>
					</tbody>
				</table>
			</div>
			<div class="col-md-2 col-md-offset-0 well">
                    <form role="form" action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post" name="newuserform">
                        <fieldset>
							<div class="form-group">
                                <label for="name">Currently Viewing:</label>
                                <?php echo $username ?>
                            </div>
                            <div class="form-group">
								<label for="sel1">Choose Student:</label>
								<select class="form-control" name="choosestudent" id="choosestudent" onClick="activate()">
									<option selected="selected" disabled>Template</option>
									<?php
										foreach($userlist as $k=>$v) {
									?>
										 <option value="<?php echo $userlist[$k]['username']; ?>"><?php echo $userlist[$k]["name"];?></option>
									<?php } ?>
								</select>
							</div>
        
                            <div class="form-group">
                                <input type="submit" name="choose" id="choose" value="Choose" class="btn btn-primary" disabled />
                            </div>
                        </fieldset>
                    </form>
                    <span class="text-success"><?php if (isset($successmsg2)) { echo $successmsg2; } ?></span>
                    <span class="text-danger"><?php if (isset($errormsg2)) { echo $errormsg2; } ?></span>
            </div>
		</div>
    </div>
	<br>
<?php } ?>

<script src="js/jquery-1.10.2.js"></script>
<script src="js/bootstrap.min.js"></script>
</body>
</html>