<?php
session_start();
include_once 'dbconnect.php';

if (is_null($_SESSION['user_id'])) {
    header("Location: index.php");
}

if ($_SESSION['user_rank'] == "Student") {
	header("Location: index.php");
}

$db_handle = new DBController();
$sql = "SELECT * from neettemplate";
$faq = $db_handle->runQuery($sql);
$username = "neettemplate";
$conn = $db_handle->connectDB();

$allusers = "SELECT * from students where rank = 'Student'";
$userlist = $db_handle->runQuery($allusers);

$allobs = "SELECT id from neettemplate";
$obslist = $db_handle->runQuery($allobs);
$number = array(1, 2, 3, 4, 5, 6, 7, 8, 9, 10);

if (isset($_POST['addrows'])) {
    $location = mysqli_real_escape_string($conn, $_POST['location']);
	if ($numrows = mysqli_real_escape_string($conn, $_POST['numrows'])) {}
	else {$numrows = 1;}
	
	foreach($userlist as $k=>$v) {
		$tables[$k] = $userlist[$k]["username"];
	}
	array_push($tables, "neettemplate");
	
	mysqli_query($conn, "SET AUTOCOMMIT=0");
	mysqli_query($conn, "START TRANSACTION");

	foreach($tables as $k=>$v) {
	
		$add = "UPDATE " .$tables[$k]. " SET id = id + " .$numrows. " WHERE id >= " .$location. " order by id DESC";
		$addexec = $db_handle->executeUpdate($add);
		for ($i=$location; $i < ($location + $numrows); $i++) {
			$add2 = "INSERT INTO " .$tables[$k]. " (id) VALUES (".$i.")";
			$add2exec = $db_handle->executeUpdate($add2);
		}
		$add3 = "ALTER TABLE " .$tables[$k]. " ORDER BY id ASC";
		$add3exec = $db_handle->executeUpdate($add3);
	
	}
	
	if($addexec && $add3exec) {
		mysqli_query($conn, "COMMIT");
		header("Location: trackeredit.php");
		$successmsg2 = "Successfully inserted rows! Page will reload in 3s.";
	}
	else {
		$errormsg2 = "Insertion Error: Please try again later";
		mysqli_query($conn, "ROLLBACK");
	}
}

if (isset($_POST['deleterows'])) {
    $location = mysqli_real_escape_string($conn, $_POST['dellocation']);
	if ($numrows = mysqli_real_escape_string($conn, $_POST['delnumrows'])) {}
	else {$numrows = 1;}	

	foreach($userlist as $k=>$v) {
		$tables[$k] = $userlist[$k]["username"];
	}
	array_push($tables, "neettemplate");
	
	mysqli_query($conn, "SET AUTOCOMMIT=0");
	mysqli_query($conn, "START TRANSACTION");

	foreach($tables as $k=>$v) {
	
		for ($i=$location; $i < ($location + $numrows); $i++) {
			$delete = "DELETE FROM " .$tables[$k]. " WHERE id= ".$i;
			$deleteexec = $db_handle->executeUpdate($delete);
		}
		$delete2 = "UPDATE " .$tables[$k]. " SET id = id - " .$numrows. " WHERE id >= " .$location. " order by id ASC";
		$delete2exec = $db_handle->executeUpdate($delete2);
		$delete3 = "ALTER TABLE " .$tables[$k]. " ORDER BY id ASC";
		$delete3exec = $db_handle->executeUpdate($delete3);
	
	}
	
	if($delete2exec && $delete3exec) {
		mysqli_query($conn, "COMMIT");
		header("Location: trackeredit.php");
		$successmsg3 = "Successfully deleted rows!";
	}
	else {
		$errormsg3 = "Deletion Error: Please try again later";
		mysqli_query($conn, "ROLLBACK");
	}
}

$addfunc = false;
if (isset($_POST['addfunc'])) {
    $addfunc = true;
}

$deletefunc = false;
if (isset($_POST['deletefunc'])) {
    $deletefunc = true;
}

/* https://stackoverflow.com/questions/6333623/mysql-syntax-for-inserting-a-new-row-in-middle-rows */
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit - NEET Tracker</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport" >
	
	<style>
			.tbl-qa{width: 100%;font-size:0.9em;background-color: #FDFDFD;}
			.tbl-qa th.table-header {padding: 5px;text-align: left;padding:10px;background-color: #f5f5f5;border-bottom:1pt solid black;}
			.tbl-qa .table-row td {padding:10px; border-bottom:2pt solid #FDFDFD;}
			.tbl-qa td.columnodd {background-color: #F5F5F5;}
	</style>
	<script src="http://code.jquery.com/jquery-1.10.2.js"></script>
		<script>
		function showEdit(editableObj) {
			$(editableObj).css("background",""); //#FFF in ""
		} 
		
		function saveToDatabase(editableObj,column,id,table) {
			$(editableObj).css("background"," url(loaderIcon.gif) no-repeat right"); //#FFF before "url"
			$.ajax({
				url: "saveedit.php",
				type: "POST",
				data:'column='+column+'&editval='+editableObj.innerHTML+'&id='+id+'&table='+table,
				success: function(data){
					$(editableObj).css("background",""); //#FDFDFD in ""
				}        
		   });
		}
		
		function activateadd() {
			$('#location').one('change', function() {
				$('#addrows').prop('disabled', false);
			});
		}
		
		function activatedelete() {
			$('#dellocation').one('change', function() {
				$('#deleterows').prop('disabled', false);
			});
		}
		</script>
	
    <link rel="stylesheet" href="css/bootstrap.min.css" type="text/css" />
</head>
<body>

<nav class="navbar navbar-default" role="navigation">
    <div class="container-fluid">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar1">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a class="navbar-brand" href="index.php">NEET Tracker</a>
        </div>
        <div class="collapse navbar-collapse" id="navbar1">
            <ul class="nav navbar-nav navbar-left">
                <?php if (isset($_SESSION['user_id'])) { ?>
				<?php if ($_SESSION['user_rank'] == "Student") { ?>
                <li class=""><a href="tracker.php">Tracker</a></li>
				<?php } ?>
				<?php if ($_SESSION['user_rank'] == "Admin") { ?>
				<li class=""><a href="trackerkey.php">Key</a></li>
				<li class=""><a href="trackers.php">Trackers</a></li>
				<li class="active"><a href="trackeredit.php">Edit</a></li>
				<li class=""><a href="students.php">Students</a></li>
				<?php } ?>
                <?php } ?>
            </ul>
            <ul class="nav navbar-nav navbar-right">
                <?php if (isset($_SESSION['user_id'])) { ?>
                <li><p class="navbar-text">Signed in as <b><?php echo $_SESSION['user_name']; ?></b></p></li>
                <li><a href="account.php">My Account</a></li>
                <li><a href="logout.php">Log Out</a></li>
                <?php } else { ?>
                <li><a href="login.php">Login</a></li>
                <!--<li><a href="register.php">Sign Up</a></li>-->
                <?php } ?>
            </ul>
        </div>
    </div>
</nav>

<?php if (isset($_SESSION['user_id'])) { ?>
    <div class="container">
		<div class="row">
			<div class="col-sm-8 col-md-10">
				<table class="tbl-qa">
					<thead>
						<tr>
							<th class="table-header" width="2%">ID</th>
							<th class="table-header" width="6%">Date</th>
							<th class="table-header" width="5%">Day #</th>
							<th class="table-header" width="20%">Module</th>
							<th class="table-header" width="20%">Tasks</th>
						</tr>
					</thead>
					<tbody>
						<?php
							foreach($faq as $k=>$v) {
						?>
						<tr class="table-row">
							<td class="columnodd" contenteditable="false" onBlur="saveToDatabase(this,'id','<?php echo $faq[$k]["id"]; ?>', 'neettemplate');" onClick="showEdit(this);"><?php echo $faq[$k]["id"]; ?></td>
							<td contenteditable="true" onBlur="saveToDatabase(this,'date','<?php echo $faq[$k]["id"]; ?>', 'neettemplate');<?php foreach($userlist as $a=>$b) { if ($userlist[$a]["different"] == 0) { ?>saveToDatabase(this,'date','<?php echo $faq[$k]["id"]; ?>', '<?php echo $userlist[$a]["username"];?>');<?php }} ?>" onClick="showEdit(this);"><?php echo $faq[$k]["date"]; ?></td>
							<td class="columnodd" contenteditable="true" onBlur="saveToDatabase(this,'Day','<?php echo $faq[$k]["id"]; ?>', 'neettemplate');<?php foreach($userlist as $a=>$b) { if ($userlist[$a]["different"] == 0) { ?>saveToDatabase(this,'Day','<?php echo $faq[$k]["id"]; ?>', '<?php echo $userlist[$a]["username"];?>');<?php }} ?>" onClick="showEdit(this);" onClick="showEdit(this);"><?php echo $faq[$k]["Day"]; ?></td>
							<td contenteditable="true" onBlur="saveToDatabase(this,'Module','<?php echo $faq[$k]["id"]; ?>', 'neettemplate');<?php foreach($userlist as $a=>$b) { if ($userlist[$a]["different"] == 0) { ?>saveToDatabase(this,'Module','<?php echo $faq[$k]["id"]; ?>', '<?php echo $userlist[$a]["username"];?>');<?php }} ?>" onClick="showEdit(this);" onClick="showEdit(this);"><?php echo $faq[$k]["Module"]; ?></td>
							<td class="columnodd" contenteditable="true" onBlur="saveToDatabase(this,'Tasks','<?php echo $faq[$k]["id"]; ?>', 'neettemplate');<?php foreach($userlist as $a=>$b) { if ($userlist[$a]["different"] == 0) { ?>saveToDatabase(this,'Tasks','<?php echo $faq[$k]["id"]; ?>', '<?php echo $userlist[$a]["username"];?>');<?php }} ?>" onClick="showEdit(this);" onClick="showEdit(this);"><?php echo $faq[$k]["Tasks"]; ?></td>
						</tr>
						<?php
							}
						?>
					</tbody>
				</table>
			</div>
			<?php if($addfunc == true) { ?>
			<div class="col-md-2 col-md-offset-0 well">
                    <form role="form" action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post" name="addrowsform">
                        <fieldset>
							<legend>Add Rows</legend>
							<div class="form-group">
								<label for="sel1">Location:</label>
								<select class="form-control" name="location" id="location" onClick="activateadd()">
									<option selected="selected" disabled></option>
									<?php
										foreach($obslist as $c=>$d) {
									?>
										 <option value="<?php echo $obslist[$c]['id']; ?>"><?php echo $obslist[$c]["id"];?></option>
									<?php } ?>
								</select>
							</div>
							<div class="form-group">
								<label for="sel1"># of Rows:</label>
								<select class="form-control" name="numrows">
									<option selected="selected" disabled></option>
									<?php
										foreach($number as $x=>$y) {
									?>
										 <option value="<?php echo $number[$x]; ?>"><?php echo $number[$x];?></option>
									<?php } ?>
								</select>
							</div>
                            <div class="form-group">
                                <input type="submit" name="addrows" id="addrows" value="Add" class="btn btn-primary" disabled />
                            </div>
                        </fieldset>
                    </form>
                    <span class="text-success"><?php if (isset($successmsg2)) { echo $successmsg2; } ?></span>
                    <span class="text-danger"><?php if (isset($errormsg2)) { echo $errormsg2; } ?></span>
            </div>
			<?php } else { ?>
			<div class="col-md-2 col-md-offset-0 well">
                    <form role="form" action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post" name="deleterowsform">
                        <fieldset>
							<legend>Add Rows</legend>
							<div class="form-group">
                                <input type="submit" name="addfunc" id="addfunc" value="Add Rows?" class="btn btn-primary" />
                            </div>
                        </fieldset>
                    </form>
            </div>
			<?php } ?>
			<?php if($deletefunc == true) { ?>
			<div class="col-md-2 col-md-offset-0 well">
                    <form role="form" action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post" name="deleterowsform">
                        <fieldset>
							<legend>Delete Rows</legend>
							<div class="form-group">
								<label for="sel1">Location:</label>
								<select class="form-control" name="dellocation" id="dellocation" onClick="activatedelete()">
									<option selected="selected" disabled></option>
									<?php
										foreach($obslist as $c=>$d) {
									?>
										 <option value="<?php echo $obslist[$c]['id']; ?>"><?php echo $obslist[$c]["id"];?></option>
									<?php } ?>
								</select>
							</div>
							<div class="form-group">
								<label for="sel1"># of Rows:</label>
								<select class="form-control" name="delnumrows">
									<option selected="selected" disabled></option>
									<?php
										foreach($number as $x=>$y) {
									?>
										 <option value="<?php echo $number[$x]; ?>"><?php echo $number[$x];?></option>
									<?php } ?>
								</select>
							</div>
                            <div class="form-group">
                                <input type="submit" name="deleterows" id="deleterows" value="Delete" class="btn btn-primary" disabled />
                            </div>
                        </fieldset>
                    </form>
                    <span class="text-success"><?php if (isset($successmsg3)) { echo $successmsg3; } ?></span>
                    <span class="text-danger"><?php if (isset($errormsg3)) { echo $errormsg3; } ?></span>
            </div>
			<?php } else { ?>
			<div class="col-md-2 col-md-offset-0 well">
                    <form role="form" action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post" name="deleterowsform">
                        <fieldset>
							<legend>Delete Rows</legend>
							<div class="form-group">
                                <input type="submit" name="deletefunc" id="deletefunc" value="Delete Rows?" class="btn btn-primary" />
                            </div>
                        </fieldset>
                    </form>
            </div>
			<?php } ?>
		</div>
    </div>
	<br>
<?php } ?>

<script src="js/jquery-1.10.2.js"></script>
<script src="js/bootstrap.min.js"></script>
</body>
</html>