<?php
session_start();
include_once 'dbconnect.php';

//set validation error flag as false
$error = false;

//file pathinfo
$target_dir = "../facemash/pictures/";

//check if insert form is submitted
if (isset($_POST['insertcolor'])) {
    $color = mysqli_real_escape_string($con, $_POST['color']);
    $color = strtolower($color);
    
    //color name can only contain letters
    if (!preg_match("/^[a-zA-Z]+$/", $color)) {
        $error = true;
        $color_error = "Color name can only contain letters";
    }
    
    /**$pass = mysqli_query($con, "SELECT password FROM users WHERE id = '".$_SESSION['user_id']."'");
    $pass= mysqli_fetch_array($pass);
    $pass = $pass["password"];
    if(md5($oldpass) != $pass) {
        $error = true;
        $oldpass_error = "Entry does not match current password";
    }**/

    $duplicate = mysqli_query($con, "SELECT Picture FROM facemash WHERE Picture = '".$color."'");
    $num_rows = mysqli_num_rows($duplicate);
    
    if ($num_rows > 0) {
        $error = true;
        $color_error = "This color already exists";
    }
    
    /**FILE UPLOAD**/
    
    $target_file = $target_dir . basename($_FILES["picture"]["name"]);
    $imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);
    $imageFileName = pathinfo($target_file,PATHINFO_FILENAME);
    //check if file is an actual image or a fake image
    $checkfile = getimagesize($_FILES["picture"]["tmp_name"]);
    if($checkfile == false) {
        $error = true;
        $picture_error = "This file is not an image";
    }
    //check if file already exists
    else if(file_exists($target_file)) {
        $error = true;
        $picture_error = "This file already exists";
    }
    //check file size
    else if($_FILES["picture"]["size"] > 500000) {
        $error = true;
        $picture_error = "This file is too large";
    }
    //only allow certain file formats
    else if($imageFileType != "png") {
        $error = true;
        $picture_error = "Only PNG files are allowed";
    }
    else if($imageFileName != $color) {
        $error = true;
        $picture_error = "File name does not match color name";
    }
    
    if(!$error) {
        if(mysqli_query($con, "INSERT INTO facemash(Picture, Votes) VALUES('".$color."', '0')")) {
            if(move_uploaded_file($_FILES["picture"]["tmp_name"], $target_file)) {
                $successmsg = "Successfully Inserted! <a href='../facemash/' target='_blank'>Click here to Vote</a>";
            }
            else {
                $errormsg = "File Insertion Error: Please try again later";
                mysqli_query($con, "DELETE FROM facemash WHERE Picture = '".$color."'");
            }
        }
        else {
            $errormsg = "Database Error: Please try again later";
        }
    }
}

//check if delete form is submitted
if (isset($_POST['deletecolor'])) {
    $delete = mysqli_real_escape_string($con, $_POST['delete']);
    $delete = strtolower($delete);
    $path = $target_dir . $delete . ".png";
    
    /**FILE DELETE**/
    
    if (file_exists($path) && $votes = mysqli_query($con, "SELECT Votes FROM facemash WHERE Picture = '".$delete."'")) {
        $error = $error;
    }
    else {
        $error = true;
        $delete_error = "This image does not exist";
    }
    
    if(!$error) {
        if(mysqli_query($con, "DELETE FROM facemash WHERE Picture = '".$delete."'")) {
            if(unlink($path)) {
                $successmsg1 = "Successfully Deleted! <a href='../facemash/' target='_blank'>Click here to Vote</a>";
            }
            else {
                $errormsg1 = "File Deletion Error: Please try again later";
                mysqli_query($con, "INSERT INTO facemash(Picture, Votes) VALUES('".$delete."', '".$votes."')");
            }
        }
        else {
            $errormsg1 = "Database Error: Please try again later";
        }
    }
}

?>

<!DOCTYPE html>
<html>
<head>
    <title>Facemash - Admin Panel</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport" >
    <link rel="stylesheet" href="css/bootstrap.min.css" type="text/css" />
</head>
<body>

<nav class="navbar navbar-default" role="navigation">
    <div class="container-fluid">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar1">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a class="navbar-brand" href="index.php">PRANAV SANGHVI</a>
        </div>
        <div class="collapse navbar-collapse" id="navbar1">
            <ul class="nav navbar-nav navbar-left">
                <?php if (isset($_SESSION['user_id'])) { ?>
                <li><a href="livetext.php">LiveText</a></li>
                <li class="active"><a href="facemash.php">Facemash</a></li>
                <?php } ?>
            </ul>
            <ul class="nav navbar-nav navbar-right">
                <?php if (isset($_SESSION['user_id'])) { ?>
                <li><p class="navbar-text">Signed in as <b><?php echo $_SESSION['user_name']; ?></b></p></li>
                <li><a href="account.php">My Account</a></li>
                <li><a href="logout.php">Log Out</a></li>
                <?php } else { ?>
                <li><a href="login.php">Login</a></li>
                <li><a href="register.php">Sign Up</a></li>
                <?php } ?>
            </ul>
        </div>
    </div>
</nav>

<?php if (isset($_SESSION['user_id'])) { ?>
    <div class="container">
            <div class="row">
                <div class="col-md-4 col-md-offset-4 well">
                    <form role="form" action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post" name="insertcolorform" enctype="multipart/form-data">
                        <fieldset>
                            <legend>Insert New Color</legend>
        
                            <div class="form-group">
                                <label for="name">Color Name:</label>
                                <input type="text" name="color" placeholder="Enter name here" required value="<?php if($error) echo $color; ?>" class="form-control" />
                                <span class="text-danger"><?php if (isset($color_error)) echo $color_error; ?></span>
                            </div>
                            
                            <div class="form-group">
                                <label for="name">Select image to upload:</label>
                                <input type="file" name="picture" required id="picture" class="form-control" />
                                <span class="text-danger"><?php if (isset($picture_error)) echo $picture_error; ?></span>
                            </div>
                            
                            <div class="form-group">
                                <input type="submit" name="insertcolor" value="Insert Color" class="btn btn-primary" />
                            </div>
                        </fieldset>
                    </form>
                    <span class="text-success"><?php if (isset($successmsg)) { echo $successmsg; } ?></span>
                    <span class="text-danger"><?php if (isset($errormsg)) { echo $errormsg; } ?></span>
                </div>
            </div>
    </div>
    <div class="container">
            <div class="row">
                <div class="col-md-4 col-md-offset-4 well">
                    <form role="form" action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post" name="deletecolorform" enctype="multipart/form-data">
                        <fieldset>
                            <legend>Delete Color</legend>
        
                            <div class="form-group">
                                <label for="name">Color Name:</label>
                                <input type="text" name="delete" placeholder="Enter name here" required value="<?php if($error) echo $delete; ?>" class="form-control" />
                                <span class="text-danger"><?php if (isset($delete_error)) echo $delete_error; ?></span>
                            </div>
                            
                            <div class="form-group">
                                <input type="submit" name="deletecolor" value="Delete Color" class="btn btn-primary" />
                            </div>
                        </fieldset>
                    </form>
                    <span class="text-success"><?php if (isset($successmsg1)) { echo $successmsg1; } ?></span>
                    <span class="text-danger"><?php if (isset($errormsg1)) { echo $errormsg1; } ?></span>
                </div>
            </div>
    </div>
    <div class="container">
            <div class="row">
                <div class="col-md-4 col-md-offset-4 well">
                    <form role="form" action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post" name="insertcolorform" enctype="multipart/form-data">
                        <fieldset>
                            <legend>Change Color Votes</legend>
        
                            <div class="form-group">
                                <label for="name">Color Name:</label>
                                <input type="text" name="color" placeholder="Enter name here" required value="<?php if($error) echo $color; ?>" class="form-control" />
                                <span class="text-danger"><?php if (isset($color_error)) echo $color_error; ?></span>
                            </div>
                            
                            <div class="form-group">
                                <label for="name">Select image to upload:</label>
                                <input type="file" name="picture" required id="picture" class="form-control" />
                                <span class="text-danger"><?php if (isset($picture_error)) echo $picture_error; ?></span>
                            </div>
                            
                            <div class="form-group">
                                <input type="submit" name="insertcolor" value="Insert Color" class="btn btn-primary" />
                            </div>
                        </fieldset>
                    </form>
                    <span class="text-success"><?php if (isset($successmsg)) { echo $successmsg; } ?></span>
                    <span class="text-danger"><?php if (isset($errormsg)) { echo $errormsg; } ?></span>
                </div>
            </div>
    </div>
<?php } ?>

<script src="js/jquery-1.10.2.js"></script>
<script src="js/bootstrap.min.js"></script>
</body>
</html>