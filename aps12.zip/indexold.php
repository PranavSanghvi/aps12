<!DOCTYPE html>
<!--[if lte IE 6]><html class="preIE7 preIE8 preIE9"><![endif]-->
<!--[if IE 7]><html class="preIE8 preIE9"><![endif]-->
<!--[if IE 8]><html class="preIE9"><![endif]-->
<!--[if gte IE 9]><!--><html><!--<![endif]-->
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="http://fonts.googleapis.com/css?family=Roboto:700,400&subset=cyrillic,latin,greek,vietnamese" rel="stylesheet" type="text/css">
  <meta name="description" content="">
  <title>Pranav Sanghvi</title>
  <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css" type="text/css">
  <link rel="stylesheet" href="assets/socicon/css/socicon.min.css" type="text/css">
  <link rel="stylesheet" href="assets/animate.css/animate.min.css" type="text/css">
  <link rel="stylesheet" href="assets/style.css" type="text/css">
  <link rel="stylesheet" href="assets/mbr-additional.css" type="text/css">
  
  
</head>
<body>
<section id="header1-0" class="hero-1 center dark mbr-v-middle mbr-fullscreen mbr-parallax-background" style="background-color: #000000;" data-effect="fadeIn">
    <div>
        <div class="container">
            <div class="row">
                <div class="col-sm-7" data-effect="fadeInUp">
                    <div class="hero">
                        
                        
                        <h1>PRANAV SANGHVI</h1><p><br></p>
                    
                    
                    </div>
                        <div class="group">
                            <a class="btn btn-lg btn-default" href="./facemash/" id="note-editor-16">Facemash</a>
                            <a class="btn btn-lg btn-default" href="./bubblepop/" id="note-editor-17">BubblePop</a>
                            <a class="btn btn-lg btn-default" href="http://quik.one/0x2v78" id="note-editor-18">Floppy Bird App</a>
                            <a class="btn btn-lg btn-default" href="http://quik.one/5IKvHS" id="note-editor-19">Bubble Pop App</a>
                            <a class="btn btn-lg btn-default" href="domains" id="note-editor-20">My Domains</a>
                            <a class="btn btn-lg btn-default" href="./cloud/" id="note-editor-21">Cloud</a>
                        </div>
                </div>
            </div>
        </div>
    </div>
</section>
<script src="assets/jquery/jquery.min.js" type="text/javascript"></script>
<script src="assets/bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
<!--<div class="mobirise_engine" style="position: absolute; left: -1000px; top: -1000px; opacity: 0.1;"><a href="http://mobirise.com/">best free website creator</a> by Mobirise 1.6.2</div>-->
<script src="assets/jquery-parallax/jquery.parallax.js" type="text/javascript"></script>
<script src="assets/social-likes/social-likes.js" type="text/javascript"></script>
<script src="assets/jquery-viewport-checker/jquery.viewportchecker.js" type="text/javascript"></script>
<script src="assets/jquery-mb-ytplayer/jquery.mb.YTPlayer.min.js" type="text/javascript"></script>
<script src="assets/script.js" type="text/javascript"></script>

  
</body>
</html>