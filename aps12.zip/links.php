<!DOCTYPE html>
<html>
<head><meta charset="utf-8">
<title>Pranav Sanghvi- Links</title>
</head>

<body link="#FF7F00" vlink="#FF7F00" alink="#FF7F00"> 
    <a href="./facemash/">Facemash</a>
    <br>
    <a href="./bubblepop/">BubblePop</a>
    <br>
    <a href="http://quik.one/0x2v78">Floppy Bird App</a>
    <br>
    <a href="http://quik.one/5IKvHS">Bubble Pop App</a>
    <br>
    <a href="http://pranavsanghvi.party">PranavSanghvi.Party</a>
    <br>
    <a href="http://pranavsanghvi.webcam">PranavSanghvi.Webcam</a>
</body>

</html>
