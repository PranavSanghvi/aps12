<?php
session_start();
include_once 'dbconnect.php';

//set validation error flag as false
$error = false;

//check if form is submitted
if (isset($_POST['changepass'])) {
    $oldpass = mysqli_real_escape_string($con, $_POST['oldpass']);
    $newpass = mysqli_real_escape_string($con, $_POST['newpass']);
    $cnewpass = mysqli_real_escape_string($con, $_POST['cnewpass']);
    
    //old password checks out
    
    $pass = mysqli_query($con, "SELECT password FROM users WHERE id = '".$_SESSION['user_id']."'");
    $pass= mysqli_fetch_array($pass);
    $pass = $pass["password"];
    if(md5($oldpass) != $pass) {
        $error = true;
        $oldpass_error = "Entry does not match current password";
    }
    //new password must be 6 or more characters
    if(strlen($newpass) < 6) {
        $error = true;
        $newpass_error = "Password must be a minimum of 6 characters";
    }
    //passwords must match
    if($newpass != $cnewpass) {
        $error = true;
        $cnewpass_error = "Passwords don't match";
    }
    if(!$error) {
        if(mysqli_query($con, "UPDATE users SET password = '".md5($newpass)."' WHERE id = '".$_SESSION['user_id']."'")) {
            $successmsg = "Successfully Changed!";
        }
        else {
            $errormsg = "Error: Please try again later";
        }
    }
}

if (isset($_POST['changeusername'])) {
    $newusername = mysqli_real_escape_string($con, $_POST['newusername']);
    
    //no duplicates
    $duplicate = mysqli_query($con, "SELECT username FROM users WHERE username = '".$newusername."'");
    $num_rows = mysqli_num_rows($duplicate);
    if ($num_rows > 0) {
        $error = true;
        $newusername_error = "This username already exists";
    }
    if(!$error) {
        if(mysqli_query($con, "UPDATE users SET username = '".$newusername."' WHERE id = '".$_SESSION['user_id']."'")) {
            $successmsg1 = "Successfully Changed!";
        }
        else {
            $errormsg1 = "Error: Please try again later";
        }
    }
}

?>

<!DOCTYPE html>
<html>
<head>
    <title>My Account - EMS Panel</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport" >
    <link rel="stylesheet" href="css/bootstrap.min.css" type="text/css" />
</head>
<body>

<nav class="navbar navbar-default" role="navigation">
    <div class="container-fluid">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar1">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a class="navbar-brand" href="index.php">EMS</a>
        </div>
        <div class="collapse navbar-collapse" id="navbar1">
            <ul class="nav navbar-nav navbar-left">
                <?php if (isset($_SESSION['user_id'])) { ?>
                <li><a href="newcall.php">New Call</a></li>
                <li><a href="calls.php">Call List</a></li>
                <?php } ?>
            </ul>
            <ul class="nav navbar-nav navbar-right">
                <?php if (isset($_SESSION['user_id'])) { ?>
                <li><p class="navbar-text">Signed in as <b><?php echo $_SESSION['user_name']; ?></b></p></li>
                <li class="active"><a href="account.php">My Account</a></li>
                <li><a href="logout.php">Log Out</a></li>
                <?php } else { ?>
                <li><a href="login.php">Login</a></li>
                <li><a href="register.php">Sign Up</a></li>
                <?php } ?>
            </ul>
        </div>
    </div>
</nav>

<?php if (isset($_SESSION['user_id'])) { ?>
    <div class="container">
            <div class="row">
                <div class="col-md-4 col-md-offset-4 well">
                    <form role="form" action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post" name="changepassform">
                        <fieldset>
                            <legend>Change Password</legend>
        
                            <div class="form-group">
                                <label for="name">Old Password:</label>
                                <input type="password" name="oldpass" placeholder="Old Password" required value="<?php if($error) echo $oldpass; ?>" class="form-control" />
                                <span class="text-danger"><?php if (isset($oldpass_error)) echo $oldpass_error; ?></span>
                            </div>
                            
                            <div class="form-group">
                                <label for="name">New Password:</label>
                                <input type="password" name="newpass" placeholder="New Password" required value="<?php if($error) echo $newpass; ?>" class="form-control" />
                                <span class="text-danger"><?php if (isset($newpass_error)) echo $newpass_error; ?></span>
                            </div>
                            
                            <div class="form-group">
                                <label for="name">Confirm New Password:</label>
                                <input type="password" name="cnewpass" placeholder="Confirm New Password" required value="<?php if($error) echo $cnewpass; ?>" class="form-control" />
                                <span class="text-danger"><?php if (isset($cnewpass_error)) echo $cnewpass_error; ?></span>
                            </div>
                            
                            <div class="form-group">
                                <input type="submit" name="changepass" value="Change Password" class="btn btn-primary" />
                            </div>
                        </fieldset>
                    </form>
                    <span class="text-success"><?php if (isset($successmsg)) { echo $successmsg; } ?></span>
                    <span class="text-danger"><?php if (isset($errormsg)) { echo $errormsg; } ?></span>
                </div>
            </div>
    </div>
    <div class="container">
            <div class="row">
                <div class="col-md-4 col-md-offset-4 well">
                    <form role="form" action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post" name="changeusernameform">
                        <fieldset>
                            <legend>Change Username</legend>
                            
                            <div class="form-group">
                                <label for="name">New Username:</label>
                                <input type="text" name="newusername" placeholder="New Username" required value="<?php if($error) echo $newusername; ?>" class="form-control" />
                                <span class="text-danger"><?php if (isset($newusername_error)) echo $newusername_error; ?></span>
                            </div>
                            
                            <div class="form-group">
                                <input type="submit" name="changeusername" value="Change Username" class="btn btn-primary" />
                            </div>
                        </fieldset>
                    </form>
                    <span class="text-success"><?php if (isset($successmsg1)) { echo $successmsg1; } ?></span>
                    <span class="text-danger"><?php if (isset($errormsg1)) { echo $errormsg1; } ?></span>
                </div>
            </div>
    </div>
<?php } ?>

<script src="js/jquery-1.10.2.js"></script>
<script src="js/bootstrap.min.js"></script>
</body>
</html>