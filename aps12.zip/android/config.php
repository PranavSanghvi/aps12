	<?php
$db = (object)array(
'host' => 'pranav-sanghvi.com.mysql',
'user' => 'pranav_sanghvi_',
'pass' => 'E3hzQFiS',
'name' => 'pranav_sanghvi_'
);
$_CONFIG['url'] = 'http://pranav-sanghvi.com/android';
?>