<?php
    $db = (object)array(
    'host' => 'fdb16.awardspace.net',
    'user' => '2394712_db',
    'pass' => 'E3hzQFiS',
    'name' => '2394712_db'
    );
    $url = 'http://aps12.dx.am/';
    $verifyurl = 'http://aps12.dx.am/adm/';
?>
