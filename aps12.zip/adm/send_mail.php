<?php
function Send_Mail($to,$subject,$body)
{
require 'https://code.google.com/a/apache-extras.org/p/phpmailer/source/browse/trunk/class.phpmailer.php';
$from       = "do-not-reply@pranav-sanghvi.com";
$mail       = new PHPMailer();
$mail->IsSMTP(true);            // use SMTP
$mail->IsHTML(true);
$mail->SMTPAuth   = true;                  // enable SMTP authentication
$mail->Host       = "smtp.gmail.com"; // SMTP host
$mail->Port       =  465;                    // set the SMTP port
$mail->Username   = "pranav.sanghvi1@gmail.com";  // SMTP  username
$mail->Password   = "Snehadidi@1998";  // SMTP password
$mail->SetFrom($from, 'Pranav Sanghvi');
$mail->Subject    = $subject;
$mail->MsgHTML($body);
$address = $to;
$mail->AddAddress($address, $to);
$mail->Send(); 
}
?>