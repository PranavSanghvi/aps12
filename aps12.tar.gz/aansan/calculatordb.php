<?php
session_start();
include_once 'dbconnect.php';

//set up
$model = 'house 1';

//set initial cost
//$cost = 500000;
$cost = mysql_query("SELECT cost FROM models WHERE model = '".$model."'");
$cost = mysql_fetch_assoc($cost);
$cost = (int)$cost;



//set initial options
$option1 = "No";
$option2 = "No";
$option3 = "No";

//set option costs
$cost1 = 500;
$cost2 = 500;
$cost3 = 500;

//calculate cost
if (isset($_POST['calculate'])) {
	$option1 = $_POST['option1'];
	if ($option1 == "Yes") {          
		$cost = $cost + $cost1;
	}
	$option2 = $_POST['option2'];
	if ($option2 == "Yes") {          
		$cost = $cost + $cost2;
	}
	$option3 = $_POST['option3'];
	if ($option3 == "Yes") {          
		$cost = $cost + $cost3;
	}
}

?>

<!DOCTYPE html>
<html>
<head>
    <title>Cost Calculator</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport" >
    <link rel="stylesheet" href="css/bootstrap.min.css" type="text/css" />
</head>
<body>

<nav class="navbar navbar-default" role="navigation">
    <div class="container-fluid">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar1">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a class="navbar-brand" href="index.php">AANSAN</a>
        </div>
        <div class="collapse navbar-collapse" id="navbar1">
            <ul class="nav navbar-nav navbar-left">
                <?php // if (isset($_SESSION['user_id'])) { ?>
                <li class="active"><a href="calculator.php">Calculator</a></li>
                <?php // } ?>
            </ul>
            <ul class="nav navbar-nav navbar-right">
                <?php if (isset($_SESSION['user_id'])) { ?>
                <li><p class="navbar-text">Signed in as <b><?php echo $_SESSION['user_name']; ?></b></p></li>
                <li><a href="account.php">My Account</a></li>
                <li><a href="logout.php">Log Out</a></li>
                <?php } else { ?>
                <li><a href="login.php">Login</a></li>
                <!--<li><a href="register.php">Sign Up</a></li>-->
                <?php } ?>
            </ul>
        </div>
    </div>
</nav>

<?php // if (isset($_SESSION['user_id'])) { ?>
    <div class="container">
		<div class="row">
			<div class="col-md-4 col-md-offset-3 well">
				<form class="form-horizontal" role="form" action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post" name="deletecolorform" enctype="multipart/form-data">
					<fieldset>
						<legend>House Options</legend>
						<!-- Option 1 -->
						<div class="form-group">
							<label class="col-md-4 control-label" for="option1">Option 1 (<?php echo $cost1; ?>)</label>
								<div class="col-md-4 col-md-offset-1"> 
									<label class="radio-inline">
										<input type="radio" name="option1" value="Yes" <?php if($option1 == "Yes") {echo 'checked="checked"';} ?>>
										Yes 
									</label> 
									<label class="radio-inline"">
										<input type="radio" name="option1" value="No" <?php if($option1 == "No") {echo 'checked="checked"';} ?>>
										No
									</label>
								</div>
							</label>
						</div>
						<!-- Option 2 -->
						<div class="form-group">
						<label class="col-md-4 control-label" for="option2">Option 2 (<?php echo $cost2; ?>)</label>
								<div class="col-md-4 col-md-offset-1"> 
									<label class="radio-inline"">
										<input type="radio" name="option2" value="Yes" <?php if($option2 == "Yes") {echo 'checked="checked"';} ?>>
										Yes 
									</label> 
									<label class="radio-inline">
										<input type="radio" name="option2" value="No" <?php if($option2 == "No") {echo 'checked="checked"';} ?>>
										No
									</label>
								</div>
							</label>
						</div>
						<!-- Option 3 -->
						<div class="form-group">
						<label class="col-md-4 control-label" for="option3">Option 3 (<?php echo $cost3; ?>)</label>
								<div class="col-md-4 col-md-offset-1"> 
									<label class="radio-inline"">
										<input type="radio" name="option3" value="Yes" <?php if($option3 == "Yes") {echo 'checked="checked"';} ?>>
										Yes 
									</label> 
									<label class="radio-inline">
										<input type="radio" name="option3" value="No" <?php if($option3 == "No") {echo 'checked="checked"';} ?>>
										No
									</label>
								</div>
							</label>
						</div>
						<!-- Submit -->
						<div class="form-group">
							<div class="col-md-4 col-md-offset-1">
                                <input type="submit" name="calculate" value="Calculate Cost" class="btn btn-primary" />
							</div>
                        </div>
					</fieldset>
				</form>
			</div>
			<div class="col-md-2 col-md-offset-0 well">
				<fieldset>
					<legend>Cost of House</legend>
					<div class="form-group">
						<h2 align="center"><label for="name">$<?php echo $cost; ?></label></h2>
					</div>
					<div class="form-group">
						<div class="col-md-4 col-md-offset-1">
                            <a href="#" onclick="window.print();return false;"><input type="submit" name="print" value="Print" class="btn btn-primary" /></a>
						</div>
                    </div>
				</fieldset>
			</div>
		</div>
    </div>
<?php // } ?>

<script src="js/jquery-1.10.2.js"></script>
<script src="js/bootstrap.min.js"></script>
</body>
</html>