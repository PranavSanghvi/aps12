<?php
// MYSQL //
include("config.php");

// DATABASE CONNECTION //
mysql_connect($db->host, $db->user, $db->pass); 
mysql_select_db($db->name);

//$value = mysql_query("SELECT `value` FROM `android` WHERE `id` = '1'");

$row = mysql_query("SELECT * FROM android ORDER BY id");
$sql = mysql_fetch_assoc($row)



?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" style="height:100%;">

<head>
<title>Pranav Sanghvi</title>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<link href="style.css" rel="stylesheet" type="text/css" />
<link href="icon.ico" rel="shortcut icon" type="image/x-icon" />
<link href="icon.ico" rel="icon" type="image/x-icon" />
<script type="text/javascript" src="js/arial.js"></script>
</head>

<body bgcolor="#282828">
    <div id="container"><div id="content"><p class="value" align="center"><?php echo $sql['value']; ?></p></div></div>
</body>

</html>