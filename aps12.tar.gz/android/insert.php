<?php
  define('HOST','pranav-sanghvi.com.mysql');
  define('USER','pranav_sanghvi_');
  define('PASS','E3hzQFiS');
  define('DB','pranav_sanghvi_');
  $con = mysqli_connect(HOST,USER,PASS,DB);

  $value = $_POST['value'];
  
  $sql = "UPDATE `android` SET `value` = '".$value."' WHERE `id` = '1'";
  //$sql = "insert into android (value) values ('$value')";

  if(mysqli_query($con,$sql)){
    //echo 'success';
  }
  else{
    //echo 'failure';
  }
  mysqli_close($con);
?>