<?php
session_start();
include_once 'dbconnect.php';

//require_once("dbcontroller.php");
$db_handle = new DBController();
$sql = "SELECT * from calls";
$faq = $db_handle->runQuery($sql);

?>

<!DOCTYPE html>
<html>
<head>
    <title>Call List - EMS Panel</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport" >
	
	<style>
			.tbl-qa{width: 100%;font-size:0.9em;background-color: #FDFDFD;}
			.tbl-qa th.table-header {padding: 5px;text-align: left;padding:10px;background-color: #f5f5f5;border-bottom:1pt solid black;}
			.tbl-qa .table-row td {padding:10px;}
			.tbl-qa td.columnodd {background-color: #F5F5F5;}
	</style>
	<script src="http://code.jquery.com/jquery-1.10.2.js"></script>
		<script>
		function showEdit(editableObj) {
			$(editableObj).css("background",""); //#FFF in ""
		} 
		
		function saveToDatabase(editableObj,column,id) {
			$(editableObj).css("background"," url(loaderIcon.gif) no-repeat right"); //#FFF before "url"
			$.ajax({
				url: "saveedit.php",
				type: "POST",
				data:'column='+column+'&editval='+editableObj.innerHTML+'&id='+id,
				success: function(data){
					$(editableObj).css("background",""); //#FDFDFD in ""
				}        
		   });
		}
		</script>
	
    <link rel="stylesheet" href="css/bootstrap.min.css" type="text/css" />
</head>
<body>

<nav class="navbar navbar-default" role="navigation">
    <div class="container-fluid">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar1">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a class="navbar-brand" href="index.php">EMS</a>
        </div>
        <div class="collapse navbar-collapse" id="navbar1">
            <ul class="nav navbar-nav navbar-left">
                <?php if (isset($_SESSION['user_id'])) { ?>
                <li><a href="newcall.php">New Call</a></li>
                <li class="active"><a href="calls.php">Call List</a></li>
                <?php } ?>
            </ul>
            <ul class="nav navbar-nav navbar-right">
                <?php if (isset($_SESSION['user_id'])) { ?>
                <li><p class="navbar-text">Signed in as <b><?php echo $_SESSION['user_name']; ?></b></p></li>
                <li><a href="account.php">My Account</a></li>
                <li><a href="logout.php">Log Out</a></li>
                <?php } else { ?>
                <li><a href="login.php">Login</a></li>
                <!--<li><a href="register.php">Sign Up</a></li>-->
                <?php } ?>
            </ul>
        </div>
    </div>
</nav>

<?php if (isset($_SESSION['user_id'])) { ?>
    <div class="container">
		<div class="row">
			<div class="col-sm-8 col-md-12 ">
				<table class="tbl-qa">
					<thead>
						<tr>
							<th class="table-header" width="3%"></th>
							<th class="table-header" width="8%">Date</th>
							<th class="table-header" width="25%">Call Description</th>
							<th class="table-header" width="8%">Transport</th>
							<th class="table-header" width="14%">Vitals</th>
							<th class="table-header" width="14%">Respiratory</th>
							<th class="table-header" width="14%">Other Skills</th>
							<th class="table-header" width="14%">Medications</th>
						</tr>
					</thead>
					<tbody>
						<?php
							foreach($faq as $k=>$v) {
						?>
						<!--
						This is the not fixed editable part
						<tr class="table-row">
							<td tabindex="1" class="columnodd"><?php echo $k+1; ?></td>
							<td tabindex="2" contenteditable="true" onBlur="saveToDatabase(this,'date','<?php echo $faq[$k]["id"]; ?>')" onClick="showEdit(this);"><?php echo $faq[$k]["date"]; ?></td>
							<td tabindex="3" class="columnodd" contenteditable="true" onBlur="saveToDatabase(this,'calldesc','<?php echo $faq[$k]["id"]; ?>')" onClick="showEdit(this);"><?php echo $faq[$k]["calldesc"]; ?></td>
							<td tabindex="4" contenteditable="true" onBlur="saveToDatabase(this,'transport','<?php echo $faq[$k]["id"]; ?>')" onClick="showEdit(this);"><?php if ($faq[$k]["transport"] == 1) {echo "yes";} else {echo "no";}; ?></td>
							<td tabindex="5" class="columnodd" contenteditable="true" onBlur="saveToDatabase(this,'N0','<?php echo $faq[$k]["id"]; ?>')" onClick="showEdit(this);"><?php echo $faq[$k]["N0"]; ?></td>
							<td tabindex="6" contenteditable="true" onBlur="saveToDatabase(this,'N2','<?php echo $faq[$k]["id"]; ?>')" onClick="showEdit(this);"><?php echo $faq[$k]["N2"]; ?></td>
							<td tabindex="7" class="columnodd" contenteditable="true" onBlur="saveToDatabase(this,'N4','<?php echo $faq[$k]["id"]; ?>')" onClick="showEdit(this);"><?php echo $faq[$k]["N4"]; ?></td>
							<td tabindex="8" contenteditable="true" onBlur="saveToDatabase(this,'N8','<?php echo $faq[$k]["id"]; ?>')" onClick="showEdit(this);"><?php echo $faq[$k]["N8"]; ?></td>
						</tr>
						-->
						<!-- Not editable -->
						<tr class="table-row">
							<td tabindex="1" class="columnodd"><?php echo $k+1; ?></td>
							<td tabindex="2" contenteditable="false"><?php echo $faq[$k]["date"]; ?></td>
							<td tabindex="3" class="columnodd" contenteditable="false"><?php echo $faq[$k]["calldesc"]; ?></td>
							<td tabindex="4" contenteditable="false"><?php if ($faq[$k]["transport"] == 1) {echo "yes";} else {echo "no";}; ?></td>
							<td tabindex="5" class="columnodd" contenteditable="false"><?php if ($faq[$k]["check1"] == 1) {echo "auscultation<br>";};
																								if ($faq[$k]["check2"] == 1) {echo "blood pressure<br>";};
																								if ($faq[$k]["check3"] == 1) {echo "blood sugar<br>";};
																								if ($faq[$k]["check4"] == 1) {echo "12-lead<br>";};
																								if ($faq[$k]["check5"] == 1) {echo "pupils<br>";};
																								  ?></td>
							<td tabindex="6" contenteditable="false"><?php if ($faq[$k]["check6"] == 1) {echo "non-rebreather<br>";};
																								if ($faq[$k]["check7"] == 1) {echo "bag valve mask<br>";};
																								if ($faq[$k]["check8"] == 1) {echo "nasal cannula<br>";};
																								if ($faq[$k]["check9"] == 1) {echo "CPAP<br>";};
																								if ($faq[$k]["check10"] == 1) {echo "kings airway<br>";};
																								if ($faq[$k]["check11"] == 1) {echo "OPA<br>";};
																								if ($faq[$k]["check12"] == 1) {echo "NPA<br>";};
																								if ($faq[$k]["check13"] == 1) {echo "nebulizer<br>";};
																								 ?></td>
							<td tabindex="7" class="columnodd" contenteditable="false"><?php if ($faq[$k]["check14"] == 1) {echo "IV setup<br>";};
																								if ($faq[$k]["check15"] == 1) {echo "compressions<br>";};
																								if ($faq[$k]["check16"] == 1) {echo "splint<br>";};
																								if ($faq[$k]["check17"] == 1) {echo "bandaging<br>";};
																								if ($faq[$k]["check18"] == 1) {echo "tourniquet<br>";};
																								 ?></td>
							<td tabindex="8" contenteditable="false"><?php if ($faq[$k]["check19"] == 1) {echo "oxygen<br>";};
																								if ($faq[$k]["check20"] == 1) {echo "aspirin<br>";};
																								if ($faq[$k]["check21"] == 1) {echo "nitro<br>";};
																								if ($faq[$k]["check22"] == 1) {echo "albuterol<br>";};
																								if ($faq[$k]["check23"] == 1) {echo "epinephrine<br>";};
																								if ($faq[$k]["check24"] == 1) {echo "glucose<br>";};
																								if ($faq[$k]["check25"] == 1) {echo "ibuprofen<br>";};
																								if ($faq[$k]["check26"] == 1) {echo "narcan<br>";};
																								if ($faq[$k]["check27"] == 1) {echo "diphenhydramine<br>";};
																								 ?></td>
						</tr>
						<?php
							}
						?>
					</tbody>
				</table>
			</div>
		</div>
    </div>
	<br>
<?php } ?>

<script src="js/jquery-1.10.2.js"></script>
<script src="js/bootstrap.min.js"></script>
</body>
</html>