<?php
session_start();

include_once 'dbconnect.php';

//set validation error flag as false
$error = false;

//check if form is submitted
if (isset($_POST['submitcall'])) {
    $date = mysqli_real_escape_string($con, $_POST['date']);
    $calldesc = mysqli_real_escape_string($con, $_POST['calldesc']);
	if (isset($_POST['transport'])) {
		$transport = mysqli_real_escape_string($con, $_POST['transport']);
	} else {
		$error = true;
		$transport_error = "Please select whether or not transport was initiated";
	};
	$transport = mysqli_real_escape_string($con, $_POST['transport']);
	if (isset($_POST['check1'])) {$check1 = 1;} else {$check1 = 0;};
	if (isset($_POST['check2'])) {$check2 = 1;} else {$check2 = 0;};
	if (isset($_POST['check3'])) {$check3 = 1;} else {$check3 = 0;};
	if (isset($_POST['check4'])) {$check4 = 1;} else {$check4 = 0;};
	if (isset($_POST['check5'])) {$check5 = 1;} else {$check5 = 0;};
	if (isset($_POST['check6'])) {$check6 = 1;} else {$check6 = 0;};
	if (isset($_POST['check7'])) {$check7 = 1;} else {$check7 = 0;};
	if (isset($_POST['check8'])) {$check8 = 1;} else {$check8 = 0;};
	if (isset($_POST['check9'])) {$check9 = 1;} else {$check9 = 0;};
	if (isset($_POST['check10'])) {$check10 = 1;} else {$check10 = 0;};
	if (isset($_POST['check11'])) {$check11 = 1;} else {$check11 = 0;};
	if (isset($_POST['check12'])) {$check12 = 1;} else {$check12 = 0;};
	if (isset($_POST['check13'])) {$check13 = 1;} else {$check13 = 0;};
	if (isset($_POST['check14'])) {$check14 = 1;} else {$check14 = 0;};
	if (isset($_POST['check15'])) {$check15 = 1;} else {$check15 = 0;};
	if (isset($_POST['check16'])) {$check16 = 1;} else {$check16 = 0;};
	if (isset($_POST['check17'])) {$check17 = 1;} else {$check17 = 0;};
	if (isset($_POST['check18'])) {$check18 = 1;} else {$check18 = 0;};
	if (isset($_POST['check19'])) {$check19 = 1;} else {$check19 = 0;};
	if (isset($_POST['check20'])) {$check20 = 1;} else {$check20 = 0;};
	if (isset($_POST['check21'])) {$check21 = 1;} else {$check21 = 0;};
	if (isset($_POST['check22'])) {$check22 = 1;} else {$check22 = 0;};
	if (isset($_POST['check23'])) {$check23 = 1;} else {$check23 = 0;};
	if (isset($_POST['check24'])) {$check24 = 1;} else {$check24 = 0;};
	if (isset($_POST['check25'])) {$check25 = 1;} else {$check25 = 0;};
	if (isset($_POST['check26'])) {$check26 = 1;} else {$check26 = 0;};
	if (isset($_POST['check27'])) {$check27 = 1;} else {$check27 = 0;};

	
    
    if(!$error) {
        if(mysqli_query($con, "INSERT INTO calls(date, calldesc, transport, check1, check2, check3, check4, check5, check6, check7, check8, check9, check10, check11, check12, check13, check14, check15, check16, check17, check18, check19, check20, check21, check22, check23, check24, check25, check26, check27) VALUES('".$date."', '".$calldesc."', '".$transport."', '".$check1	."' , '".$check2."' , '".$check3."' , '".$check4."' , '".$check5."' , '".$check6."' , '".$check7."' , '".$check8."' , '".$check9."' , '".$check10."' , '".$check11."' , '".$check12."' , '".$check13."' , '".$check14."' , '".$check15."' , '".$check16."' , '".$check17."' , '".$check18."' , '".$check19."' , '".$check20."' , '".$check21."' , '".$check22."' , '".$check23."' , '".$check24."' , '".$check25."' , '".$check26."' , '".$check27."')")) {
            $successmsg = "Successfully Entered!";
        }
        else {
            $errormsg = "Error: Please try again later";
        }
    }
}
?>

<!DOCTYPE html>
<html>
    <head>
        <title>New Call - EMS Panel</title>
        <meta content="width=device-width, initial-scale=1.0" name="viewport" >
        <link rel="stylesheet" href="css/bootstrap.min.css" type="text/css" />
    </head>
    <body>
        <nav class="navbar navbar-default" role="navigation">
            <div class="container-fluid">
                <!-- add header -->
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar1">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="index.php">EMS</a>
                </div>
                <!-- menu items -->
                <div class="collapse navbar-collapse" id="navbar1">
            <ul class="nav navbar-nav navbar-left">
                <?php if (isset($_SESSION['user_id'])) { ?>
                <li class="active"><a href="newcall.php">New Call</a></li>
                <li><a href="calls.php">Call List</a></li>
                <?php } ?>
            </ul>
            <ul class="nav navbar-nav navbar-right">
                <?php if (isset($_SESSION['user_id'])) { ?>
                <li><p class="navbar-text">Signed in as <b><?php echo $_SESSION['user_name']; ?></b></p></li>
                <li><a href="account.php">My Account</a></li>
                <li><a href="logout.php">Log Out</a></li>
                <?php } else { ?>
                <li><a href="login.php">Login</a></li>
                <!--<li><a href="register.php">Sign Up</a></li>-->
                <?php } ?>
            </ul>
        </div>
            </div>
        </nav>
		
	<?php if (isset($_SESSION['user_id'])) { ?>
        
        <div class="container">
            <div class="row">
                <div class="col-md-4 col-md-offset-4 well">
                    <form role="form" action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post" name="newcallform">
                        <fieldset>
                            <legend>New Call</legend>
        
                            <div class="form-group">
                                <label for="name">Date</label>
                                <input type="date" name="date" placeholder="Date" required value="<?php if($error) echo $date; ?>" class="form-control" />
                                <!--<span class="text-danger"><?php if (isset($date_error)) echo $date_error; ?></span>-->
                            </div>
							
							<div class="form-group">
                                <label for="name">Call Description</label>
                                <!--<input type="text" name="calldesc" placeholder="Call Description" required value="<?php if($error) echo $calldesc; ?>" class="form-control" />-->
								<textarea name="calldesc" placeholder="Call Description" required value="<?php if($error) echo $calldesc; ?>" class="form-control" rows="3" /></textarea>
                                <!--<span class="text-danger"><?php if (isset($caldesc_error)) echo $caldesc_error; ?></span>-->
                            </div>

                            <div class="form-group">
                                <label for="name">Transport?</label>							
								<div class="form-check form-check-inline">
									<label class="form-check-label col-md-3">
										<input class="form-check-input" type="radio" name="transport" value="1"> Yes
									</label>
									<label class="form-check-label">	
										<input class="form-check-input" type="radio" name="transport" value="0"> No
									</label>
								</div>
								<span class="text-danger"><?php if (isset($transport_error)) echo $transport_error; ?></span>
							</div>
								
							<div class="form-group">
                                <label for="name">Vitals:</label>
							</div>
							
							<div class="form-group">
                                <label for="name">Auscultation</label>
								<input class="form-check-input col-md-2" type="checkbox" name="check1" value="check1">
                            </div>
							
							<div class="form-group">
                                <label for="name">Blood Pressure</label>
								<input class="form-check-input col-md-2" type="checkbox" name="check2" value="check2">
                            </div>
							
							<div class="form-group">
                                <label for="name">Blood Sugar</label>
								<input class="form-check-input col-md-2" type="checkbox" name="check3" value="check3">
                            </div>
							
							<div class="form-group">
                                <label for="name">12-Lead</label>
								<input class="form-check-input col-md-2" type="checkbox" name="check4" value="check4">
                            </div>
							
							<div class="form-group">
                                <label for="name">Pupils</label>
								<input class="form-check-input col-md-2" type="checkbox" name="check5" value="check5">
                            </div>
							
							<div class="form-group">
                                <label for="name">Respiratory:</label>
							</div>
							
							<div class="form-group">
                                <label for="name">Non-Rebreather</label>
								<input class="form-check-input col-md-2" type="checkbox" name="check6" value="check6">
                            </div>
							
							<div class="form-group">
                                <label for="name">Bag Valve Mask</label>
								<input class="form-check-input col-md-2" type="checkbox" name="check7" value="check7">
                            </div>
							
							<div class="form-group">
                                <label for="name">Nasal Cannula</label>
								<input class="form-check-input col-md-2" type="checkbox" name="check8" value="check8">
                            </div>
							
							<div class="form-group">
                                <label for="name">CPAP</label>
								<input class="form-check-input col-md-2" type="checkbox" name="check9" value="check9">
                            </div>
							
							<div class="form-group">
                                <label for="name">Kings Airway</label>
								<input class="form-check-input col-md-2" type="checkbox" name="check10" value="check10">
                            </div>
							
							<div class="form-group">
                                <label for="name">OPA</label>
								<input class="form-check-input col-md-2" type="checkbox" name="check11" value="check11">
                            </div>
							
							<div class="form-group">
                                <label for="name">NPA</label>
								<input class="form-check-input col-md-2" type="checkbox" name="check12" value="check12">
                            </div>
							
							<div class="form-group">
                                <label for="name">Nebulizer</label>
								<input class="form-check-input col-md-2" type="checkbox" name="check13" value="check13">
                            </div>
							
							<div class="form-group">
                                <label for="name">Other Skills:</label>
							</div>
							
							<div class="form-group">
                                <label for="name">IV Setup</label>
								<input class="form-check-input col-md-2" type="checkbox" name="check14" value="chec14">
                            </div>
							
							<div class="form-group">
                                <label for="name">Compressions</label>
								<input class="form-check-input col-md-2" type="checkbox" name="check15" value="check15">
                            </div>
							
							<div class="form-group">
                                <label for="name">Splint</label>
								<input class="form-check-input col-md-2" type="checkbox" name="check16" value="check16">
                            </div>
							
							<div class="form-group">
                                <label for="name">Bandaging</label>
								<input class="form-check-input col-md-2" type="checkbox" name="check17" value="check17">
                            </div>
							
							<div class="form-group">
                                <label for="name">Tourniquet</label>
								<input class="form-check-input col-md-2" type="checkbox" name="check18" value="check18">
                            </div>
							
							<div class="form-group">
                                <label for="name">Medications Given:</label>
							</div>
							
							<div class="form-group">
                                <label for="name">Oxygen</label>
								<input class="form-check-input col-md-2" type="checkbox" name="check19" value="check19">
                            </div>
							
							<div class="form-group">
                                <label for="name">Aspirin</label>
								<input class="form-check-input col-md-2" type="checkbox" name="check20" value="check20">
                            </div>
							
							<div class="form-group">
                                <label for="name">Nitro</label>
								<input class="form-check-input col-md-2" type="checkbox" name="check21" value="check21">
                            </div>
							
							<div class="form-group">
                                <label for="name">Albuterol</label>
								<input class="form-check-input col-md-2" type="checkbox" name="check22" value="check22">
                            </div>
							
							<div class="form-group">
                                <label for="name">Epinephrine</label>
								<input class="form-check-input col-md-2" type="checkbox" name="check23" value="check23">
                            </div>
							
							<div class="form-group">
                                <label for="name">Glucose</label>
								<input class="form-check-input col-md-2" type="checkbox" name="check24" value="check24">
                            </div>
							
							<div class="form-group">
                                <label for="name">Ibuprofen</label>
								<input class="form-check-input col-md-2" type="checkbox" name="check25" value="check25">
                            </div>
							
							<div class="form-group">
                                <label for="name">Narcan</label>
								<input class="form-check-input col-md-2" type="checkbox" name="check26" value="check26">
                            </div>
							
							<div class="form-group">
                                <label for="name">Diphenhydramine</label>
								<input class="form-check-input col-md-2" type="checkbox" name="check27" value="check27">
                            </div>
                            
                            <div class="form-group">
                                <input type="submit" name="submitcall" value="Submit Call" class="btn btn-primary" />
                            </div>
                        </fieldset>
                    </form>
                    <span class="text-success"><?php if (isset($successmsg)) { echo $successmsg; } ?></span>
                    <span class="text-danger"><?php if (isset($errormsg)) { echo $errormsg; } ?></span>
                </div>
            </div>
        </div>
		
	<?php } ?>
	
        <script src="js/jquery-1.10.2.js"></script>
        <script src="js/bootstrap.min.js"></script>
    </body>
</html>
    
