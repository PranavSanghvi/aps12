<?php
require_once("dbcontroller.php");
$db_handle = new DBController();
$sql = "SELECT * from duke";
$faq = $db_handle->runQuery($sql);
?>
<html>
    <head>
      <title>PHP MySQL Inline Editing using jQuery Ajax</title>
		<style>
			body{width:610px;}
			.current-row{background-color:#B24926;color:#FFF;}
			.current-col{background-color:#1b1b1b;color:#FFF;}
			.tbl-qa{width: 100%;font-size:0.9em;background-color: #f5f5f5;}
			.tbl-qa th.table-header {padding: 5px;text-align: left;padding:10px;}
			.tbl-qa .table-row td {padding:10px;background-color: #FDFDFD;}
		</style>
		<script src="http://code.jquery.com/jquery-1.10.2.js"></script>
		<script>
		function showEdit(editableObj) {
			$(editableObj).css("background","#FFF");
		} 
		
		function saveToDatabase(editableObj,column,id) {
			$(editableObj).css("background","#FFF url(loaderIcon.gif) no-repeat right");
			$.ajax({
				url: "saveedit.php",
				type: "POST",
				data:'column='+column+'&editval='+editableObj.innerHTML+'&id='+id,
				success: function(data){
					$(editableObj).css("background","#FDFDFD");
				}        
		   });
		}
		</script>
    </head>
    <body>		
	   <table class="tbl-qa">
		  <thead>
			  <tr>
				<th class="table-header" width="10%">Q.No.</th>
				<th class="table-header">Question</th>
				<th class="table-header">Answer</th>
			  </tr>
		  </thead>
		  <tbody>
		  <?php
		  foreach($faq as $k=>$v) {
		  ?>
			  <tr class="table-row">
				<td tabindex="1" class="columnodd"><?php echo $k+1; ?></td>
							<td tabindex="2" contenteditable="false" onBlur="saveToDatabase(this,'category','<?php echo $faq[$k]["id"]; ?>')" onClick="showEdit(this);"><?php echo $faq[$k]["category"]; ?></td>
							<td tabindex="3" class="columnodd" contenteditable="true" onBlur="saveToDatabase(this,'PMH','<?php echo $faq[$k]["id"]; ?>')" onClick="showEdit(this);"><?php echo $faq[$k]["PMH"]; ?></td>
							<td tabindex="4" contenteditable="true" onBlur="saveToDatabase(this,'C','<?php echo $faq[$k]["id"]; ?>')" onClick="showEdit(this);"><?php echo $faq[$k]["C"]; ?></td>
							<td tabindex="5" class="columnodd" contenteditable="true" onBlur="saveToDatabase(this,'N0','<?php echo $faq[$k]["id"]; ?>')" onClick="showEdit(this);"><?php echo $faq[$k]["N0"]; ?></td>
							<td tabindex="6" contenteditable="true" onBlur="saveToDatabase(this,'N2','<?php echo $faq[$k]["id"]; ?>')" onClick="showEdit(this);"><?php echo $faq[$k]["N2"]; ?></td>
							<td tabindex="7" class="columnodd" contenteditable="true" onBlur="saveToDatabase(this,'N4','<?php echo $faq[$k]["id"]; ?>')" onClick="showEdit(this);"><?php echo $faq[$k]["N4"]; ?></td>
							<td tabindex="8" contenteditable="true" onBlur="saveToDatabase(this,'N8','<?php echo $faq[$k]["id"]; ?>')" onClick="showEdit(this);"><?php echo $faq[$k]["N8"]; ?></td>
							<td tabindex="9" class="columnodd" contenteditable="true" onBlur="saveToDatabase(this,'N12','<?php echo $faq[$k]["id"]; ?>')" onClick="showEdit(this);"><?php echo $faq[$k]["N12"]; ?></td>
							<td tabindex="10" contenteditable="true" onBlur="saveToDatabase(this,'N16','<?php echo $faq[$k]["id"]; ?>')" onClick="showEdit(this);"><?php echo $faq[$k]["N16"]; ?></td>
							<td tabindex="11" class="columnodd" contenteditable="true" onBlur="saveToDatabase(this,'N20','<?php echo $faq[$k]["id"]; ?>')" onClick="showEdit(this);"><?php echo $faq[$k]["N20"]; ?></td>
							<td tabindex="12" contenteditable="true" onBlur="saveToDatabase(this,'N24','<?php echo $faq[$k]["id"]; ?>')" onClick="showEdit(this);"><?php echo $faq[$k]["N24"]; ?></td>
							<td tabindex="13" class="columnodd" contenteditable="true" onBlur="saveToDatabase(this,'N26','<?php echo $faq[$k]["id"]; ?>')" onClick="showEdit(this);"><?php echo $faq[$k]["N26"]; ?></td>
							<td tabindex="14" contenteditable="true" onBlur="saveToDatabase(this,'N28','<?php echo $faq[$k]["id"]; ?>')" onClick="showEdit(this);"><?php echo $faq[$k]["N28"]; ?></td>
							<td tabindex="15" class="columnodd" contenteditable="true" onBlur="saveToDatabase(this,'N36','<?php echo $faq[$k]["id"]; ?>')" onClick="showEdit(this);"><?php echo $faq[$k]["N36"]; ?></td>
							<td tabindex="16" contenteditable="true" onBlur="saveToDatabase(this,'N48','<?php echo $faq[$k]["id"]; ?>')" onClick="showEdit(this);"><?php echo $faq[$k]["N48"]; ?></td>
							<td tabindex="17" class="columnodd" contenteditable="true" onBlur="saveToDatabase(this,'FU','<?php echo $faq[$k]["id"]; ?>')" onClick="showEdit(this);"><?php echo $faq[$k]["FU"]; ?></td>
							<td tabindex="18" contenteditable="true" onBlur="saveToDatabase(this,'U1','<?php echo $faq[$k]["id"]; ?>')" onClick="showEdit(this);"><?php echo $faq[$k]["U1"]; ?></td>
							<td tabindex="19" class="columnodd" contenteditable="true" onBlur="saveToDatabase(this,'U2','<?php echo $faq[$k]["id"]; ?>')" onClick="showEdit(this);"><?php echo $faq[$k]["U2"]; ?></td>
							<td tabindex="20" contenteditable="true" onBlur="saveToDatabase(this,'U3','<?php echo $faq[$k]["id"]; ?>')" onClick="showEdit(this);"><?php echo $faq[$k]["U3"]; ?></td>
			  </tr>
		<?php
		}
		?>
		  </tbody>
		</table>
    </body>
</html>
