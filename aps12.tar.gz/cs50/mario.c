#include <cs50.h>
#include <stdio.h>

int main(void)
{
    printf("Height: ");
    int height = GetInt();
    int count = 2;
//    int error = 0;
    int block = 0;
    int scount = 0;
    int oheight = 0;
    START:if (height < 24 && height > -1)
    {
        oheight = height;
        while (height > 0)
        {
            block = count;
            
           scount = oheight + 1 - block;
            while (scount > 0)
            {
               printf(" ");
                scount--;
            }
 
            while (block > 0)
            {
                
                printf("#");
                block--;
            }
            printf("\n");
            height--;
            count++;
        }    
    }  
    else// if (error < 2)
    {
        printf("Height: ");
        height = GetInt();
//        error++;
        goto START;
    }     
//    else
//    {
//        printf("Retry: ");
//        height = GetInt();
//        error++;
//        goto START;
//    }
}
