<?php

session_start();
include("dbconnect.php");

// DATABASE CONNECTION //
mysql_connect($db->host, $db->user, $db->pass); 
mysql_select_db($db->name);

if(isset($_SESSION['user'])!="")
{
    header("Location: home.php");
}

if(isset($_POST['btn-login']))
{
    $username = mysql_real_escape_string($_POST['username']);
    $password = mysql_real_escape_string($_POST['password']);
    $res = mysql_query("SELECT * FROM users WHERE username = '".$username."'");
    $row = mysql_fetch_array($res);
    
    if($row['password']==md5($password))
    {
        $_SESSION['user'] = $row['user_id'];
        header("Location: home.php");
    }
    else
    {
        
    ?>
    
        <script>alert('wrong details');</script>
    
    <?php
        
    }
}

?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <title>Admin Login</title>
        <link rel="stylesheet" href="style1.css" type="text/css" />
        <script type="text/javascript" src="js/arial.js"></script>
    </head>
    <body bgcolor="#282828">
        <ul>
  <li><a href="#home">Home</a></li>
  <li><a href="#news">News</a></li>
  <li><a href="#contact">Contact</a></li>
  <li style="float:right"><a class="active" href="#about">About</a></li>
</ul>
        <center>
            
                <div id="content">
                    <form method="post">
                        <table id="loginform">
                            <tr>
                                <td><input type="text" name="username" placeholder="Username" required /></td>
                            </tr>
                            <tr>
                                <td><input type="password" name="password" placeholder="Password" required /></td>
                            </tr>
                            <tr>
                                <td><button type="submit" name="btn-login">Sign In</button></td>
                            </tr>
                            <tr>
                                <td><a href="register.php">Sign Up Here</a></td>
                            </tr>
                        </table>
                    </form>
                </div>
                
        </center>
    </body>
</html>