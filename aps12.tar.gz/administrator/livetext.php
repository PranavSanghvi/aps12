<?php
session_start();
include_once 'dbconnect.php';

//set validation error flag as false
$error = false;

//check if form is submitted
if (isset($_POST['updatetext'])) {
    $value = mysqli_real_escape_string($con, $_POST['value']);
    
    if(!$error) {
        if(mysqli_query($con, "UPDATE `android` SET `value` = '".$value."' WHERE `id` = '1'")) {
            $successmsg = "Successfully Updated! <a href='../android/' target='_blank'>Click here to View</a>";
        }
        else {
            $errormsg = "Database Error: Please try again later";
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>LiveText - Admin Panel</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport" >
    <link rel="stylesheet" href="css/bootstrap.min.css" type="text/css" />
    <link rel="stylesheet" href="css/bootstrap.colorpickersliders" type="text/css" />
    <script type="text/javascript" src="js/bootstrap.colorpickersliders.js"></script>
    <script type="text/javascript" src="js/bootstrap.colorpickersliders.nocielch.js"></script>
    <script>
  $("input#small").ColorPickerSliders({
    size: 'sm',
    placement: 'bottom',
    swatches: false,
    order: {
      hsl: 1
    }
  });
  $("input#smallhsv").ColorPickerSliders({
    size: 'sm',
    placement: 'right',
    swatches: false,
    sliders: false,
    hsvpanel: true
  });
  $("input#default").ColorPickerSliders({
    placement: 'bottom',
    swatches: false,
    order: {
      rgb: 1
    }
  });
  $("input#large").ColorPickerSliders({
    size: 'lg',
    placement: 'bottom',
    swatches: false,
    order: {
      cie: 1
    }
  });
  $("input#swatchesonly").ColorPickerSliders({
    placement: 'bottom',
    color: 'red',
    swatches: ['red', 'green', 'blue'],
    customswatches: false,
    order: {}
  });
  $("input#hslswatches").ColorPickerSliders({
    placement: 'bottom',
    order: {
      hsl: 1,
      opacity: 2
    }
  });
</script>
</head>
<body>

<nav class="navbar navbar-default" role="navigation">
    <div class="container-fluid">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar1">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a class="navbar-brand" href="index.php">PRANAV SANGHVI</a>
        </div>
        <div class="collapse navbar-collapse" id="navbar1">
            <ul class="nav navbar-nav navbar-left">
                <?php if (isset($_SESSION['user_id'])) { ?>
                <li class="active"><a href="livetext.php">LiveText</a></li>
                <li><a href="facemash.php">Facemash</a></li>
                <?php } ?>
            </ul>
            <ul class="nav navbar-nav navbar-right">
                <?php if (isset($_SESSION['user_id'])) { ?>
                <li><p class="navbar-text">Signed in as <b><?php echo $_SESSION['user_name']; ?></b></p></li>
                <li><a href="account.php">My Account</a></li>
                <li><a href="logout.php">Log Out</a></li>
                <?php } else { ?>
                <li><a href="login.php">Login</a></li>
                <li><a href="register.php">Sign Up</a></li>
                <?php } ?>
            </ul>
        </div>
    </div>
</nav>

<?php if (isset($_SESSION['user_id'])) { ?>
    <div class="container">
            <div class="row">
                <div class="col-md-4 col-md-offset-4 well">
                    <form role="form" action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post" name="updatetextform">
                        <fieldset>
                            <legend>Update LiveText</legend>
        
                            <div class="form-group">
                                <label for="name">LiveText:</label>
                                <input type="text" name="value" placeholder="Enter text here" required value="<?php if($error) echo $value; ?>" class="form-control" />
                            </div>
                            
                            <div class="form-group">
                                <input type="submit" name="updatetext" value="Update Text" class="btn btn-primary" />
                            </div>
                        </fieldset>
                    </form>
                    <span class="text-success"><?php if (isset($successmsg)) { echo $successmsg; } ?></span>
                    <span class="text-danger"><?php if (isset($errormsg)) { echo $errormsg; } ?></span>
                </div>
            </div>
    </div>
    <div class="container">
            <div class="row">
                <div class="col-md-4 col-md-offset-4 well">
                    <form role="form" action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post" name="updatetextform">
                        <fieldset>
                            <legend>Change LiveText Color</legend>
        
                            <div class="form-group">
                                <label for="name">New Color:</label>
                                <input type="text" name="value" placeholder="Enter text here" required value="<?php if($error) echo $value; ?>" class="form-control" />
                            </div>
                            
                            <div class="form-group">
                            
                                <input type="text" class="form-control cp-preventtouchkeyboardonshow" id="full-popover" value="#A6FF00" data-color-format="hex" tabindex="-1" style="color: rgb(0, 0, 0); background: rgb(166, 255, 0);" data-original-title="" title="" readonly="">

                            </div>
                        </fieldset>
                    </form>
                    <span class="text-success"><?php if (isset($successmsg)) { echo $successmsg; } ?></span>
                    <span class="text-danger"><?php if (isset($errormsg)) { echo $errormsg; } ?></span>
                </div>
            </div>
    </div>
<?php } ?>

<script src="js/jquery-1.10.2.js"></script>
<script src="js/bootstrap.min.js"></script>
</body>
</html>