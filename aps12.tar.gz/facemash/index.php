<?php
// MYSQL //
include("config.php");

// DATABASE CONNECTION //
$con = mysqli_connect($db->host, $db->user, $db->pass, $db->name); 


// RANDOM PICTURE //
$extract = mysqli_query($con, "SELECT Picture FROM facemash");
$input = Array();
while ($row = mysqli_fetch_array($extract, MYSQLI_ASSOC)) {
    $input[] =  $row['Picture'];  
}

//$input = array("black", "blue", "gray", "lime", "orange", "pink", "purple", "red", "skyblue", "yellow");
$rand_keys = array_rand($input, 2);
$pic1 =  $input[$rand_keys[0]] . "\n";
$pic2 =  $input[$rand_keys[1]] . "\n";

//POPUP
/* $popup = '<div id="overlay">
	<div class="dialog">
		<h1>Welcome to The New Facemash!</h1>
		<p>
			A warm welcome from the creator <BR>of Facemash!
			<BR><BR>Please feel free to vote for your<BR>favorite pictures.
			<BR><BR>To view the most voted, click on the <b>results</b> button.
			<a id="continue" class="button-link">
				<div id="continue" class="button-content" style="margin-right:170px;">Lets do this!</div>
			</a>
		</p>
	</div>
</div>'; */

$popup = '<script>
  sweetAlert("Welcome to The New Facemash!", "Please feel free to vote for your favorite pictures. To view the most voted, click on the results button.");
</script>';

if(isset($_GET['voted']))
{
    $popup = '';
}

// CLICK FIRST PICTURE //
if(isset($_POST['picture1']))
{
//echo "<script type='text/javascript'>alert('Voting is temporarily disabled for maintenance.')</script>";
$picname1 = strtoupper($_POST['picname1']);
mysqli_query($con, "UPDATE `facemash` SET `Votes` = Votes + '1' WHERE `Picture` = '".$picname1."'") OR DIE('ERROR: ' . mysql_error());
}

// CLICK SECOND PICTURE //
if(isset($_POST['picture2']))
{
//echo "<script type='text/javascript'>alert('Voting is temporarily disabled for maintenance.')</script>";
$picname2 = strtoupper($_POST['picname2']);
mysqli_query($con, "UPDATE `facemash` SET `Votes` = Votes + '1' WHERE `Picture` = '".$picname2."'") OR DIE('ERROR: ' . mysql_error());
}


?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" style="height:100%;">

<head>
<title>The New Facemash</title>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<link href="style.css" rel="stylesheet" type="text/css" />
<link href="icon.ico" rel="shortcut icon" type="image/x-icon" />
<link href="icon.ico" rel="icon" type="image/x-icon" />
<link href='http://fonts.googleapis.com/css?family=Ubuntu:400,500,700,400italic,500italic,700italic' rel='stylesheet' type='text/css'>
<script type="text/javascript" src="js/arial.js"></script>
<script type="text/javascript" src="http://code.jquery.com/jquery-1.7.js"></script>
<script type="text/javascript">
$(document).ready(function(){
	$('div#continue').click(function(){
		$('#overlay').fadeOut(1000);
	});
	$('div#overlay').click(function(){
		$('#overlay').fadeOut(1000);
	});
});
</script>

<script src="dist/sweetalert.min.js"></script> <link rel="stylesheet" type="text/css" href="dist/sweetalert.css">

</head>

<body>

<?php echo $popup ?>

<table class="border">
	<tr>
		<td>
			<p class="title" align="center">The New Facemash!</p>
			<br /><br />
			<table align="center" style="width:100%;">
				<tr>
					<td align="left" class="picture1"><form action="http://aps12.dx.am/facemash/index.php?voted" method="post"><input type="image" src="pictures/<?php echo $pic1 ?>.png" name="picture1" value="picture1"><input class="hidden" type="text" name="picname1" placeholder="<?php echo $pic1 ?>" autocomplete="on" value="<?php echo $pic1 ?>"/></form></td>
					<td align="center"><div class="or"></div></td>
					<td align="right" class="picture2"><form action="http://aps12.dx.am/facemash/index.php?voted" method="post"><input type="image" src="pictures/<?php echo $pic2 ?>.png" name="picture2" value="picture2"><input class="hidden" type="text" name="picname2" placeholder="<?php echo $pic2 ?>" autocomplete="on" value="<?php echo $pic2 ?>"/></form></td>
				</tr>
			</table>
			<table align="center" style="width:100%; height:100%; padding: 3.5% 0% 0% 0%;">
				<tr>
					<td>
					<div align="center">
					<a href="results.php"><img src="./pictures/fm/results2.png" onmouseover="this.src='./pictures/fm/results1.png'" onmouseout="this.src='./pictures/fm/results2.png'"></a>
					</div
					</td>
				</tr>
			</table>
			<br/><br/>
		</td>
	</tr>
</table>

</body>

</html>