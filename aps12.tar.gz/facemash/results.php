<?php
// MYSQL //
include("config.php");

// DATABASE CONNECTION //
$con = mysqli_connect($db->host, $db->user, $db->pass, $db->name);

$more = 0;
$limit = 5;

if ($more == 0)
{
$display = '<input type="image" name="5more" value="5more" src="./pictures/fm/5more2.png" onmouseover="this.src=\'./pictures/fm/5more1.png\'" onmouseout="this.src=\'./pictures/fm/5more2.png\'">';
}

// CLICK 5 MORE //
if(isset($_POST['5more']))
{
$limit = $limit + 5;
$more = 1;
}

if ($more == 1)
{
    $display = '<input type="image" name="5less" value="5less" src="./pictures/fm/5less2.png" onmouseover="this.src=\'./pictures/fm/5less1.png\'" onmouseout="this.src=\'./pictures/fm/5less2.png\'">';
}

// CLICK 5 LESS //
if(isset($_POST['5less']))
{
$limit = 5;
$more = 0;
}

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" style="height:100%;">

<head>
<title>The New Facemash: Results</title>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<link href="style.css" rel="stylesheet" type="text/css" />
<link href="icon.ico" rel="shortcut icon" type="image/x-icon" />
<link href="icon.ico" rel="icon" type="image/x-icon" />
<script type="text/javascript" src="js/arial.js"></script>
</head>

<body>
<table class="border">
	<tr>
		<td>
			<p class="title" align="center">The New Facemash: Current Leaders</p>
			<br />
			<table align="center" class="resultsborder">
				<tr style="outline: thick solid black;">
					<td align="center">Rank</td>
					<td align="center">Picture</td>
					<td align="center"># Votes</td>
				</tr>
				<tr><td><br></td></tr>
				<?php
				$row = mysqli_query($con, "SELECT * FROM facemash ORDER BY Votes DESC LIMIT $limit");
				$rank = 0;
				while($sql = mysqli_fetch_assoc($row)){
					$rank += 1;
				?>
				<tr>
					<td width="5%" align="center"><?php echo $rank;?></td>
					<td width="15%" align="center"><img src="./pictures/<?php echo $sql['Picture']; ?>.png" height="50%"></td>
					<td width="7%" align="center"><?php echo $sql['Votes']; ?></td>
				</tr>
					  <?php } ?>
				<tr>
				<td align="center" colspan="3"><br>
				<form action="" method="post"><?php echo $display;?></form>
				<br></td>
				</tr>
					
			</table>
			<table align="center" style="width:100%; padding: 3.5% 0% 0% 0%;">
				<tr>
					<td>
					<div align="center">
					<a href="index.php?voted"><img src="./pictures/fm/home2.png" onmouseover="this.src='./pictures/fm/home1.png'" onmouseout="this.src='./pictures/fm/home2.png'"></a>
					</div>
					</td>
				</tr>
			</table>
			<br/><br/>
		</td>
	</tr>
</table>
</body>

</html>