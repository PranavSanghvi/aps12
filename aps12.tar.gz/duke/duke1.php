<?php
session_start();
include_once 'dbconnect.php';
$db_handle = new DBController();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Duke</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport" >
	
	<style>
			.tbl-qa{width: 100%;font-size:0.9em;background-color: #FDFDFD;}
			.tbl-qa th.table-header {padding: 5px;text-align: left;padding:10px;background-color: #f5f5f5;border-bottom:1pt solid black;}
			.tbl-qa th.title {padding: 5px;text-align: left;padding:10px; font-size:1.3em;}
			.tbl-qa .table-row td {padding:10px;}
			.tbl-qa td.columnodd {background-color: #F5F5F5;}
	</style>
	<script src="http://code.jquery.com/jquery-1.10.2.js"></script>
		
	
    <link rel="stylesheet" href="css/bootstrap.min.css" type="text/css" />
</head>
<body>

<nav class="navbar navbar-default" role="navigation">
    <div class="container-fluid">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar1">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a class="navbar-brand" href="index.php">DUKE</a>
        </div>
        <div class="collapse navbar-collapse" id="navbar1">
            <ul class="nav navbar-nav navbar-left">
                <?php if (isset($_SESSION['user_id'])) { ?>
                <li class="active"><a href="duke.php">Duke</a></li>
                <?php } ?>
            </ul>
            <ul class="nav navbar-nav navbar-right">
                <?php if (isset($_SESSION['user_id'])) { ?>
                <li><p class="navbar-text">Signed in as <b><?php echo $_SESSION['user_name']; ?></b></p></li>
                <li><a href="account.php">My Account</a></li>
                <li><a href="logout.php">Log Out</a></li>
                <?php } else { ?>
                <li><a href="login.php">Login</a></li>
                <!--<li><a href="register.php">Sign Up</a></li>-->
                <?php } ?>
            </ul>
        </div>
    </div>
</nav>

<?php // if (isset($_SESSION['user_id'])) { ?>
    <div class="container">
		<div class="row">
			<div class="col-sm-8 col-md-12 ">
				<?php
					for ($x=1; $x=38; $x++)	{
						$result = mysql_query("SELECT * FROM duke WHERE id = $i");
						$row = mysql_fetch_row($result);
						if (in_array("y", $row) OR in_array("Y", $row)) {
							include ('tables/table' . $i . '.php');
						}
					}
				?>
				
			</div>
		</div>
    </div>
	<br>
<?php // } ?>

<script src="js/jquery-1.10.2.js"></script>
<script src="js/bootstrap.min.js"></script>
</body>
</html>