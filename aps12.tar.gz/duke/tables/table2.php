<?php
session_start();
include_once 'dbconnect.php';
$db_handle = new DBController();
$sql = "SELECT * from table2";
$faq = $db_handle->runQuery($sql);
?>

<script>
	function saveToDatabase2(editableObj,column,id) {
		$(editableObj).css("background"," url(loaderIcon.gif) no-repeat right"); //#FFF before "url"
		$.ajax({
			url: "saveedit2.php",
			type: "POST",
			data:'column='+column+'&editval='+editableObj.innerHTML+'&id='+id,
			success: function(data){
				$(editableObj).css("background",""); //#FDFDFD in ""
			}        
	   });
	}
</script>

<style>
	.left {float:left;}
	.right {float:right; width:25%;}
</style>

<table class="tbl-qa">
	<thead>
		<tr>
			<th class="title" colspan="21">2. Fevers, colds or infections</th>
		</tr>
		<tr>
			<th class="table-header" width="22%">L54: Bacterial, viral, parasitic or suspected infection</th>
			<th class="table-header" colspan="2" width="7.8%"><div align="center">Screen</div><br><div><div class="left">PMH</div><div class="right">C</div></div></th>
			<!--<th class="table-header" width="3.9%">C</th>-->
			<th class="table-header" width="3.9%">0</th>
			<th class="table-header" width="3.9%">2</th>
			<th class="table-header" width="3.9%">4</th>
			<th class="table-header" width="3.9%">8</th>
			<th class="table-header" width="3.9%">12</th>
			<th class="table-header" width="3.9%">16</th>
			<th class="table-header" width="3.9%">20</th>
			<th class="table-header" width="3.9%">24</th>
			<th class="table-header" width="3.9%">26</th>
			<th class="table-header" width="3.9%">28</th>
			<th class="table-header" width="3.9%">36</th>
			<th class="table-header" width="3.9%">48</th>
			<th class="table-header" width="3.9%">FU</th>
			<th class="table-header" width="3.9%">U</th>
			<th class="table-header" width="3.9%">U</th>
			<th class="table-header" width="3.9%">U</th>
			<th class="table-header" width="3.9%">SAE</th>
			<th class="table-header" width="3.9%">Rel to Trnt</th>
		</tr>
	</thead>
	<tbody>
		<?php
			foreach (array_slice($faq, 0, 4) as $k => $v) {
		?>
		<tr class="table-row">
			<td tabindex="1" contenteditable="false" onBlur="saveToDatabase2(this,'category','<?php echo $faq[$k]["id"]; ?>')" onClick="showEdit(this);"><?php echo $faq[$k]["category"]; ?></td>
			<td tabindex="2" class="columnodd" contenteditable="true" onBlur="saveToDatabase2(this,'PMH','<?php echo $faq[$k]["id"]; ?>')" onClick="showEdit(this);"><?php echo $faq[$k]["PMH"]; ?></td>
			<td tabindex="3" contenteditable="true" onBlur="saveToDatabase2(this,'C','<?php echo $faq[$k]["id"]; ?>')" onClick="showEdit(this);"><?php echo $faq[$k]["C"]; ?></td>
			<td tabindex="4" class="columnodd" contenteditable="true" onBlur="saveToDatabase2(this,'N0','<?php echo $faq[$k]["id"]; ?>')" onClick="showEdit(this);"><?php echo $faq[$k]["N0"]; ?></td>
			<td tabindex="5" contenteditable="true" onBlur="saveToDatabase2(this,'N2','<?php echo $faq[$k]["id"]; ?>')" onClick="showEdit(this);"><?php echo $faq[$k]["N2"]; ?></td>
			<td tabindex="6" class="columnodd" contenteditable="true" onBlur="saveToDatabase2(this,'N4','<?php echo $faq[$k]["id"]; ?>')" onClick="showEdit(this);"><?php echo $faq[$k]["N4"]; ?></td>
			<td tabindex="7" contenteditable="true" onBlur="saveToDatabase2(this,'N8','<?php echo $faq[$k]["id"]; ?>')" onClick="showEdit(this);"><?php echo $faq[$k]["N8"]; ?></td>
			<td tabindex="8" class="columnodd" contenteditable="true" onBlur="saveToDatabase2(this,'N12','<?php echo $faq[$k]["id"]; ?>')" onClick="showEdit(this);"><?php echo $faq[$k]["N12"]; ?></td>
			<td tabindex="9" contenteditable="true" onBlur="saveToDatabase2(this,'N16','<?php echo $faq[$k]["id"]; ?>')" onClick="showEdit(this);"><?php echo $faq[$k]["N16"]; ?></td>
			<td tabindex="10" class="columnodd" contenteditable="true" onBlur="saveToDatabase2(this,'N20','<?php echo $faq[$k]["id"]; ?>')" onClick="showEdit(this);"><?php echo $faq[$k]["N20"]; ?></td>
			<td tabindex="11" contenteditable="true" onBlur="saveToDatabase2(this,'N24','<?php echo $faq[$k]["id"]; ?>')" onClick="showEdit(this);"><?php echo $faq[$k]["N24"]; ?></td>
			<td tabindex="12" class="columnodd" contenteditable="true" onBlur="saveToDatabase2(this,'N26','<?php echo $faq[$k]["id"]; ?>')" onClick="showEdit(this);"><?php echo $faq[$k]["N26"]; ?></td>
			<td tabindex="13" contenteditable="true" onBlur="saveToDatabase2(this,'N28','<?php echo $faq[$k]["id"]; ?>')" onClick="showEdit(this);"><?php echo $faq[$k]["N28"]; ?></td>
			<td tabindex="14" class="columnodd" contenteditable="true" onBlur="saveToDatabase2(this,'N36','<?php echo $faq[$k]["id"]; ?>')" onClick="showEdit(this);"><?php echo $faq[$k]["N36"]; ?></td>
			<td tabindex="15" contenteditable="true" onBlur="saveToDatabase2(this,'N48','<?php echo $faq[$k]["id"]; ?>')" onClick="showEdit(this);"><?php echo $faq[$k]["N48"]; ?></td>
			<td tabindex="16" class="columnodd" contenteditable="true" onBlur="saveToDatabase2(this,'FU','<?php echo $faq[$k]["id"]; ?>')" onClick="showEdit(this);"><?php echo $faq[$k]["FU"]; ?></td>
			<td tabindex="17" contenteditable="true" onBlur="saveToDatabase2(this,'U1','<?php echo $faq[$k]["id"]; ?>')" onClick="showEdit(this);"><?php echo $faq[$k]["U1"]; ?></td>
			<td tabindex="18" class="columnodd" contenteditable="true" onBlur="saveToDatabase2(this,'U2','<?php echo $faq[$k]["id"]; ?>')" onClick="showEdit(this);"><?php echo $faq[$k]["U2"]; ?></td>
			<td tabindex="19" contenteditable="true" onBlur="saveToDatabase2(this,'U3','<?php echo $faq[$k]["id"]; ?>')" onClick="showEdit(this);"><?php echo $faq[$k]["U3"]; ?></td>
			<td tabindex="20" class="columnodd" contenteditable="true" onBlur="saveToDatabase2(this,'SAE','<?php echo $faq[$k]["id"]; ?>')" onClick="showEdit(this);"><?php echo $faq[$k]["SAE"]; ?></td>
			<td tabindex="21" contenteditable="true" onBlur="saveToDatabase2(this,'RTT','<?php echo $faq[$k]["id"]; ?>')" onClick="showEdit(this);"><?php echo $faq[$k]["RTT"]; ?></td>
		</tr>
		<?php
			}
		?>
	</tbody>
	<thead>
		<tr>
			<th class="table-header" width="22%">C6: Fever, w/out suspected infection</th>
			<th class="table-header" colspan="2" width="7.8%"><div align="center">Screen</div><br><div><div class="left">PMH</div><div class="right">C</div></div></th>
			<!--<th class="table-header" width="3.9%">C</th>-->
			<th class="table-header" width="3.9%">0</th>
			<th class="table-header" width="3.9%">2</th>
			<th class="table-header" width="3.9%">4</th>
			<th class="table-header" width="3.9%">8</th>
			<th class="table-header" width="3.9%">12</th>
			<th class="table-header" width="3.9%">16</th>
			<th class="table-header" width="3.9%">20</th>
			<th class="table-header" width="3.9%">24</th>
			<th class="table-header" width="3.9%">26</th>
			<th class="table-header" width="3.9%">28</th>
			<th class="table-header" width="3.9%">36</th>
			<th class="table-header" width="3.9%">48</th>
			<th class="table-header" width="3.9%">FU</th>
			<th class="table-header" width="3.9%">U</th>
			<th class="table-header" width="3.9%">U</th>
			<th class="table-header" width="3.9%">U</th>
			<th class="table-header" width="3.9%">SAE</th>
			<th class="table-header" width="3.9%">Rel to Trnt</th>
		</tr>
	</thead>
	<tbody>
		<?php
			foreach (array_slice($faq, 4, 4, 4) as $k => $v) {
		?>
		<tr class="table-row">
			<td tabindex="1" contenteditable="false" onBlur="saveToDatabase2(this,'category','<?php echo $faq[$k]["id"]; ?>')" onClick="showEdit(this);"><?php echo $faq[$k]["category"]; ?></td>
			<td tabindex="2" class="columnodd" contenteditable="true" onBlur="saveToDatabase2(this,'PMH','<?php echo $faq[$k]["id"]; ?>')" onClick="showEdit(this);"><?php echo $faq[$k]["PMH"]; ?></td>
			<td tabindex="3" contenteditable="true" onBlur="saveToDatabase2(this,'C','<?php echo $faq[$k]["id"]; ?>')" onClick="showEdit(this);"><?php echo $faq[$k]["C"]; ?></td>
			<td tabindex="4" class="columnodd" contenteditable="true" onBlur="saveToDatabase2(this,'N0','<?php echo $faq[$k]["id"]; ?>')" onClick="showEdit(this);"><?php echo $faq[$k]["N0"]; ?></td>
			<td tabindex="5" contenteditable="true" onBlur="saveToDatabase2(this,'N2','<?php echo $faq[$k]["id"]; ?>')" onClick="showEdit(this);"><?php echo $faq[$k]["N2"]; ?></td>
			<td tabindex="6" class="columnodd" contenteditable="true" onBlur="saveToDatabase2(this,'N4','<?php echo $faq[$k]["id"]; ?>')" onClick="showEdit(this);"><?php echo $faq[$k]["N4"]; ?></td>
			<td tabindex="7" contenteditable="true" onBlur="saveToDatabase2(this,'N8','<?php echo $faq[$k]["id"]; ?>')" onClick="showEdit(this);"><?php echo $faq[$k]["N8"]; ?></td>
			<td tabindex="8" class="columnodd" contenteditable="true" onBlur="saveToDatabase2(this,'N12','<?php echo $faq[$k]["id"]; ?>')" onClick="showEdit(this);"><?php echo $faq[$k]["N12"]; ?></td>
			<td tabindex="9" contenteditable="true" onBlur="saveToDatabase2(this,'N16','<?php echo $faq[$k]["id"]; ?>')" onClick="showEdit(this);"><?php echo $faq[$k]["N16"]; ?></td>
			<td tabindex="10" class="columnodd" contenteditable="true" onBlur="saveToDatabase2(this,'N20','<?php echo $faq[$k]["id"]; ?>')" onClick="showEdit(this);"><?php echo $faq[$k]["N20"]; ?></td>
			<td tabindex="11" contenteditable="true" onBlur="saveToDatabase2(this,'N24','<?php echo $faq[$k]["id"]; ?>')" onClick="showEdit(this);"><?php echo $faq[$k]["N24"]; ?></td>
			<td tabindex="12" class="columnodd" contenteditable="true" onBlur="saveToDatabase2(this,'N26','<?php echo $faq[$k]["id"]; ?>')" onClick="showEdit(this);"><?php echo $faq[$k]["N26"]; ?></td>
			<td tabindex="13" contenteditable="true" onBlur="saveToDatabase2(this,'N28','<?php echo $faq[$k]["id"]; ?>')" onClick="showEdit(this);"><?php echo $faq[$k]["N28"]; ?></td>
			<td tabindex="14" class="columnodd" contenteditable="true" onBlur="saveToDatabase2(this,'N36','<?php echo $faq[$k]["id"]; ?>')" onClick="showEdit(this);"><?php echo $faq[$k]["N36"]; ?></td>
			<td tabindex="15" contenteditable="true" onBlur="saveToDatabase2(this,'N48','<?php echo $faq[$k]["id"]; ?>')" onClick="showEdit(this);"><?php echo $faq[$k]["N48"]; ?></td>
			<td tabindex="16" class="columnodd" contenteditable="true" onBlur="saveToDatabase2(this,'FU','<?php echo $faq[$k]["id"]; ?>')" onClick="showEdit(this);"><?php echo $faq[$k]["FU"]; ?></td>
			<td tabindex="17" contenteditable="true" onBlur="saveToDatabase2(this,'U1','<?php echo $faq[$k]["id"]; ?>')" onClick="showEdit(this);"><?php echo $faq[$k]["U1"]; ?></td>
			<td tabindex="18" class="columnodd" contenteditable="true" onBlur="saveToDatabase2(this,'U2','<?php echo $faq[$k]["id"]; ?>')" onClick="showEdit(this);"><?php echo $faq[$k]["U2"]; ?></td>
			<td tabindex="19" contenteditable="true" onBlur="saveToDatabase2(this,'U3','<?php echo $faq[$k]["id"]; ?>')" onClick="showEdit(this);"><?php echo $faq[$k]["U3"]; ?></td>
			<td tabindex="20" class="columnodd" contenteditable="true" onBlur="saveToDatabase2(this,'SAE','<?php echo $faq[$k]["id"]; ?>')" onClick="showEdit(this);"><?php echo $faq[$k]["SAE"]; ?></td>
			<td tabindex="21" contenteditable="true" onBlur="saveToDatabase2(this,'RTT','<?php echo $faq[$k]["id"]; ?>')" onClick="showEdit(this);"><?php echo $faq[$k]["RTT"]; ?></td>
		</tr>
		<?php
			}
		?>
	</tbody>
</table>