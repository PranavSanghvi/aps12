<?php
session_start();
include_once 'dbconnect.php';
$db_handle = new DBController();
?>


<!DOCTYPE html>
<html>
<head>
    <title>Duke</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport" >
	
	<style>
			.tbl-qa{width: 100%;font-size:0.9em;background-color: #FDFDFD;}
			.tbl-qa th.table-header {padding: 5px;text-align: left;padding:10px;background-color: #f5f5f5;border-bottom:1pt solid black;}
			.tbl-qa th.title {padding: 5px;text-align: left;padding:10px; font-size:1.3em;}
			.tbl-qa .table-row td {padding:10px;}
			.tbl-qa td.columnodd {background-color: #F5F5F5;}
	</style>
	<script src="http://code.jquery.com/jquery-1.10.2.js"></script>
		
	
    <link rel="stylesheet" href="css/bootstrap.min.css" type="text/css" />
</head>
<body>

<nav class="navbar navbar-default" role="navigation">
    <div class="container-fluid">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar1">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a class="navbar-brand" href="index.php">DUKE</a>
        </div>
        <div class="collapse navbar-collapse" id="navbar1">
            <ul class="nav navbar-nav navbar-left">
                <?php if (isset($_SESSION['user_id'])) { ?>
                <li class="active"><a href="duke.php">Duke</a></li>
                <?php } ?>
            </ul>
            <ul class="nav navbar-nav navbar-right">
                <?php if (isset($_SESSION['user_id'])) { ?>
                <li><p class="navbar-text">Signed in as <b><?php echo $_SESSION['user_name']; ?></b></p></li>
                <li><a href="account.php">My Account</a></li>
                <li><a href="logout.php">Log Out</a></li>
                <?php } else { ?>
                <li><a href="login.php">Login</a></li>
                <!--<li><a href="register.php">Sign Up</a></li>-->
                <?php } ?>
            </ul>
        </div>
    </div>
</nav>

<?php // if (isset($_SESSION['user_id'])) { ?>
    <div class="container">
		<div class="row">
			<div class="col-sm-8 col-md-12 ">
				<?php 
				$result = mysql_query("SELECT * FROM duke WHERE id = '1'");
				$row = mysql_fetch_row($result);
				if (in_array("y", $row) OR in_array("Y", $row)) {
					include 'tables/table1.php';
				}
				?>
				<?php 
				$result = mysql_query("SELECT * FROM duke WHERE id = '2'");
				$row = mysql_fetch_row($result);
				if (in_array("y", $row) OR in_array("Y", $row)) {
					include 'tables/table2.php';
				}
				?>
				<?php 
				$result = mysql_query("SELECT * FROM duke WHERE id = '3'");
				$row = mysql_fetch_row($result);
				if (in_array("y", $row) OR in_array("Y", $row)) {
					include 'tables/table3.php';
				}
				?>
				<?php 
				$result = mysql_query("SELECT * FROM duke WHERE id = '4'");
				$row = mysql_fetch_row($result);
				if (in_array("y", $row) OR in_array("Y", $row)) {
					include 'tables/table4.php';
				}
				?>
				<?php 
				$result = mysql_query("SELECT * FROM duke WHERE id = '5'");
				$row = mysql_fetch_row($result);
				if (in_array("y", $row) OR in_array("Y", $row)) {
					include 'tables/table5.php';
				}
				?>
				<?php 
				$result = mysql_query("SELECT * FROM duke WHERE id = '6'");
				$row = mysql_fetch_row($result);
				if (in_array("y", $row) OR in_array("Y", $row)) {
					include 'tables/table6.php';
				}
				?>
				<?php 
				$result = mysql_query("SELECT * FROM duke WHERE id = '7'");
				$row = mysql_fetch_row($result);
				if (in_array("y", $row) OR in_array("Y", $row)) {
					include 'tables/table7.php';
				}
				?>
				<?php 
				$result = mysql_query("SELECT * FROM duke WHERE id = '8'");
				$row = mysql_fetch_row($result);
				if (in_array("y", $row) OR in_array("Y", $row)) {
					include 'tables/table8.php';
				}
				?>
				<?php 
				$result = mysql_query("SELECT * FROM duke WHERE id = '9'");
				$row = mysql_fetch_row($result);
				if (in_array("y", $row) OR in_array("Y", $row)) {
					include 'tables/table9.php';
				}
				?>
				<?php 
				$result = mysql_query("SELECT * FROM duke WHERE id = '10'");
				$row = mysql_fetch_row($result);
				if (in_array("y", $row) OR in_array("Y", $row)) {
					include 'tables/table10.php';
				}
				?>
				<?php 
				$result = mysql_query("SELECT * FROM duke WHERE id = '11'");
				$row = mysql_fetch_row($result);
				if (in_array("y", $row) OR in_array("Y", $row)) {
					include 'tables/table11.php';
				}
				?>
				<?php 
				$result = mysql_query("SELECT * FROM duke WHERE id = '12'");
				$row = mysql_fetch_row($result);
				if (in_array("y", $row) OR in_array("Y", $row)) {
					include 'tables/table12.php';
				}
				?>
				<?php 
				$result = mysql_query("SELECT * FROM duke WHERE id = '13'");
				$row = mysql_fetch_row($result);
				if (in_array("y", $row) OR in_array("Y", $row)) {
					include 'tables/table13.php';
				}
				?>
				<?php 
				$result = mysql_query("SELECT * FROM duke WHERE id = '14'");
				$row = mysql_fetch_row($result);
				if (in_array("y", $row) OR in_array("Y", $row)) {
					include 'tables/table14.php';
				}
				?>
				<?php 
				$result = mysql_query("SELECT * FROM duke WHERE id = '15'");
				$row = mysql_fetch_row($result);
				if (in_array("y", $row) OR in_array("Y", $row)) {
					include 'tables/table15.php';
				}
				?>
				<?php 
				$result = mysql_query("SELECT * FROM duke WHERE id = '16'");
				$row = mysql_fetch_row($result);
				if (in_array("y", $row) OR in_array("Y", $row)) {
					include 'tables/table16.php';
				}
				?>
				<?php 
				$result = mysql_query("SELECT * FROM duke WHERE id = '17'");
				$row = mysql_fetch_row($result);
				if (in_array("y", $row) OR in_array("Y", $row)) {
					include 'tables/table17.php';
				}
				?>
				<?php 
				$result = mysql_query("SELECT * FROM duke WHERE id = '18'");
				$row = mysql_fetch_row($result);
				if (in_array("y", $row) OR in_array("Y", $row)) {
					include 'tables/table18.php';
				}
				?>
				<?php 
				$result = mysql_query("SELECT * FROM duke WHERE id = '19'");
				$row = mysql_fetch_row($result);
				if (in_array("y", $row) OR in_array("Y", $row)) {
					include 'tables/table19.php';
				}
				?>
				<?php 
				$result = mysql_query("SELECT * FROM duke WHERE id = '20'");
				$row = mysql_fetch_row($result);
				if (in_array("y", $row) OR in_array("Y", $row)) {
					include 'tables/table20.php';
				}
				?>
				<?php 
				$result = mysql_query("SELECT * FROM duke WHERE id = '21'");
				$row = mysql_fetch_row($result);
				if (in_array("y", $row) OR in_array("Y", $row)) {
					include 'tables/table21.php';
				}
				?>
				<?php 
				$result = mysql_query("SELECT * FROM duke WHERE id = '22'");
				$row = mysql_fetch_row($result);
				if (in_array("y", $row) OR in_array("Y", $row)) {
					include 'tables/table22.php';
				}
				?>
				<?php 
				$result = mysql_query("SELECT * FROM duke WHERE id = '23'");
				$row = mysql_fetch_row($result);
				if (in_array("y", $row) OR in_array("Y", $row)) {
					include 'tables/table23.php';
				}
				?>
				<?php 
				$result = mysql_query("SELECT * FROM duke WHERE id = '24'");
				$row = mysql_fetch_row($result);
				if (in_array("y", $row) OR in_array("Y", $row)) {
					include 'tables/table24.php';
				}
				?>
				<?php 
				$result = mysql_query("SELECT * FROM duke WHERE id = '25'");
				$row = mysql_fetch_row($result);
				if (in_array("y", $row) OR in_array("Y", $row)) {
					include 'tables/table25.php';
				}
				?>
				<?php 
				$result = mysql_query("SELECT * FROM duke WHERE id = '26'");
				$row = mysql_fetch_row($result);
				if (in_array("y", $row) OR in_array("Y", $row)) {
					include 'tables/table26.php';
				}
				?>
				<?php 
				$result = mysql_query("SELECT * FROM duke WHERE id = '27'");
				$row = mysql_fetch_row($result);
				if (in_array("y", $row) OR in_array("Y", $row)) {
					include 'tables/table27.php';
				}
				?>
				<?php 
				$result = mysql_query("SELECT * FROM duke WHERE id = '28'");
				$row = mysql_fetch_row($result);
				if (in_array("y", $row) OR in_array("Y", $row)) {
					include 'tables/table28.php';
				}
				?>
				<?php 
				$result = mysql_query("SELECT * FROM duke WHERE id = '29'");
				$row = mysql_fetch_row($result);
				if (in_array("y", $row) OR in_array("Y", $row)) {
					include 'tables/table29.php';
				}
				?>
				<?php 
				$result = mysql_query("SELECT * FROM duke WHERE id = '30'");
				$row = mysql_fetch_row($result);
				if (in_array("y", $row) OR in_array("Y", $row)) {
					include 'tables/table30.php';
				}
				?>
				<?php 
				$result = mysql_query("SELECT * FROM duke WHERE id = '311'");
				$row = mysql_fetch_row($result);
				if (in_array("y", $row) OR in_array("Y", $row)) {
					include 'tables/table31.php';
				}
				?>
				<?php 
				$result = mysql_query("SELECT * FROM duke WHERE id = '32'");
				$row = mysql_fetch_row($result);
				if (in_array("y", $row) OR in_array("Y", $row)) {
					include 'tables/table32.php';
				}
				?>
				<?php 
				$result = mysql_query("SELECT * FROM duke WHERE id = '33'");
				$row = mysql_fetch_row($result);
				if (in_array("y", $row) OR in_array("Y", $row)) {
					include 'tables/table33.php';
				}
				?>
				<?php 
				$result = mysql_query("SELECT * FROM duke WHERE id = '34'");
				$row = mysql_fetch_row($result);
				if (in_array("y", $row) OR in_array("Y", $row)) {
					include 'tables/table34.php';
				}
				?>
				<?php 
				$result = mysql_query("SELECT * FROM duke WHERE id = '35'");
				$row = mysql_fetch_row($result);
				if (in_array("y", $row) OR in_array("Y", $row)) {
					include 'tables/table35.php';
				}
				?>
				<?php 
				$result = mysql_query("SELECT * FROM duke WHERE id = '36'");
				$row = mysql_fetch_row($result);
				if (in_array("y", $row) OR in_array("Y", $row)) {
					include 'tables/table36.php';
				}
				?>
				<?php 
				$result = mysql_query("SELECT * FROM duke WHERE id = '37'");
				$row = mysql_fetch_row($result);
				if (in_array("y", $row) OR in_array("Y", $row)) {
					include 'tables/table37.php';
				}
				?>
				<?php 
				$result = mysql_query("SELECT * FROM duke WHERE id = '38'");
				$row = mysql_fetch_row($result);
				if (in_array("y", $row) OR in_array("Y", $row)) {
					include 'tables/table38.php';
				}
				?>
			</div>
		</div>
    </div>
	<br>
<?php // } ?>

<script src="js/jquery-1.10.2.js"></script>
<script src="js/bootstrap.min.js"></script>
</body>
</html>