<?php
/**
 * Database configuration
  */
define('DB_USERNAME', 'pranav_sanghvi_');
define('DB_PASSWORD', 'E3hzQFiS');
define('DB_HOST', 'pranav-sanghvi.com.mysql');
define('DB_NAME', 'pranav_sanghvi_');

define("GOOGLE_API_KEY", "AIzaSyAzjvuYh47pXmEk2MgDIG2OT2RyrkoktIQ");

//push notification flags
define('PUSH_FLAG_CHATROOM', 1);
define('PUSH_FLAG_USER', 2);

?>