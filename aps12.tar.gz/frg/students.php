<?php
session_start();
include_once 'dbconnect.php';

if (is_null($_SESSION['user_id'])) {
    header("Location: index.php");
}

if ($_SESSION['user_rank'] == "Student") {
	header("Location: index.php");
}

$db_handle = new DBController();
$conn = $db_handle->connectDB();

//set validation error flag as false
$error = false;

$disabled = false;

$removeauser = false;

//check if form is submitted
if (isset($_POST['register'])) {
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $password = mysqli_real_escape_string($conn, $_POST['password']);
    $cpassword = mysqli_real_escape_string($conn, $_POST['cpassword']);
	$rank = mysqli_real_escape_string($conn, $_POST['rank']);
	if (isset($_POST['unique'])) {
		$unique = 1;
	} else {
		$unique = 0;
	}
    
    //name can contain only alpha characters and space
    if (!preg_match("/^[a-zA-Z ]+$/", $name)) {
        $error = true;
        $name_error = "Name must contain only letters and spaces";
    }
    if (!preg_match("/^[a-zA-Z0-9]+$/", $username)) {
        $error = true;
        $username_error = "Username must use only letters and numbers";
    }
    //email must be validation
    if(!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = true;
        $email_error = "Please enter valid Email Address";
    }
    //password must be 6 or more characters
    if(strlen($password) < 6) {
        $error = true;
        $password_error = "Password must be a minimum of 6 characters";
    }
    //passwords must match
    if($password != $cpassword) {
        $error = true;
        $cpassword_error = "Passwords don't match";
    }
	//assign rank
	if($rank == "Student") {
		if(!$error && !$disabled) {
			if(mysqli_query($conn, "INSERT INTO students(name, username, email, password, rank, different) VALUES('".$name."', '".$username."', '".$email."', '".md5($password)."', '".$rank."', '".$unique."')") && mysqli_query($conn, "CREATE TABLE " .$username. " LIKE neettemplate") && mysqli_query($conn, "INSERT " .$username. " SELECT * FROM neettemplate")) {
				$successmsg = "Successfully registered new user!";
			}
			else {
				$errormsg = "Registration Error: Please try again later";
			}
		}
	}
	else {
		if(!$error && !$disabled) {
			if(mysqli_query($conn, "INSERT INTO students(name, username, email, password, rank, different) VALUES('".$name."', '".$username."', '".$email."', '".md5($password)."', '".$rank."', '".$unique."')")) {
				$successmsg = "Successfully registered new user!";
			}
			else {
				$errormsg = "Registration Error: Please try again later";
			}
		}
	}
    if($disabled) {
        $errormsg = "Registration has been disabled";
    }
}

//get list of users for remove user functionality
$allusers = "SELECT * from students";
$userlist = $db_handle->runQuery($allusers);

if (isset($_POST['remove'])) {
    $username = mysqli_real_escape_string($conn, $_POST['userremove']);
	if(mysqli_query($conn, "DELETE from students where username = '".$username."'") && mysqli_query($conn, "DROP table if exists " .$username)) {
		$successmsg2 = "Successfully removed user!";
	}
	else {
		$errormsg2 = "Deletion Error: Please try again later";
	}
}

if (isset($_POST['makeunique'])) {
    $username = mysqli_real_escape_string($conn, $_POST['unique']);
	if(mysqli_query($conn, "UPDATE students set different = 1 where username = '".$username."'")) {
		$successmsg3 = "Successfully made user unique!";
	}
	else {
		$errormsg3 = "Unique Error: Please try again later";
	}
}

if (isset($_POST['removeauser'])) {
    $removeauser = true;
}

if (isset($_POST['makeuniquefunc'])) {
    $makeuniquefunc = true;
}

?>

<!DOCTYPE html>
<html>
    <head>
        <title>Students - NEET Tracker</title>
        <meta content="width=device-width, initial-scale=1.0" name="viewport" >
        <link rel="stylesheet" href="css/bootstrap.min.css" type="text/css" />
		<script>
		function activateremove() {
			$('#userremove').one('change', function() {
				$('#remove').prop('disabled', false);
			});
		}
		function activateunique() {
			$('#unique').one('change', function() {
				$('#makeunique').prop('disabled', false);
			});
		}
		</script>
    </head>
    <body>
        <nav class="navbar navbar-default" role="navigation">
            <div class="container-fluid">
                <!-- add header -->
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar1">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="index.php">NEET Tracker</a>
                </div>
                <!-- menu items -->
                <div class="collapse navbar-collapse" id="navbar1">
            <ul class="nav navbar-nav navbar-left">
                <?php if (isset($_SESSION['user_id'])) { ?>
				<?php if ($_SESSION['user_rank'] == "Student") { ?>
                <li class=""><a href="tracker.php">Tracker</a></li>
				<?php } ?>
				<?php if ($_SESSION['user_rank'] == "Admin") { ?>
				<li class=""><a href="trackerkey.php">Key</a></li>
				<li class=""><a href="trackers.php">Trackers</a></li>
				<li class=""><a href="trackeredit.php">Edit</a></li>
				<li class="active"><a href="students.php">Students</a></li>
				<?php } ?>
                <?php } ?>
            </ul>
            <ul class="nav navbar-nav navbar-right">
                <?php if (isset($_SESSION['user_id'])) { ?>
                <li><p class="navbar-text">Signed in as <b><?php echo $_SESSION['user_name']; ?></b></p></li>
                <li><a href="account.php">My Account</a></li>
                <li><a href="logout.php">Log Out</a></li>
                <?php } else { ?>
                <li><a href="login.php">Login</a></li>
                <!--<li><a href="register.php">Sign Up</a></li>-->
                <?php } ?>
            </ul>
        </div>
            </div>
        </nav>
        
	<?php if (isset($_SESSION['user_id'])) { ?>
        <div class="container">
            <div class="row">
                <div class="col-md-4 col-md-offset-4 well">
                    <form role="form" action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post" name="newuserform">
                        <fieldset>
                            <legend>New User</legend>
        
                            <div class="form-group">
                                <label for="name">Name</label>
                                <input type="text" name="name" placeholder="Name" required value="<?php if($error) echo $name; ?>" class="form-control" />
                                <span class="text-danger"><?php if (isset($name_error)) echo $name_error; ?></span>
                            </div>
                            
                            <div class="form-group">
                                <label for="name">Username</label>
                                <input type="text" name="username" placeholder="Username" required value="<?php if($error) echo $username; ?>" class="form-control" />
                                <span class="text-danger"><?php if (isset($username_error)) echo $username_error; ?></span>
                            </div>
                            
                            <div class="form-group">
                                <label for="name">Email</label>
                                <input type="text" name="email" placeholder="Email" required value="<?php if($error) echo $email; ?>" class="form-control" />
                                <span class="text-danger"><?php if (isset($email_error)) echo $email_error; ?></span>
                            </div>
        
                            <div class="form-group">
                                <label for="name">Password</label>
                                <input type="password" name="password" placeholder="Password" required class="form-control" />
                                <span class="text-danger"><?php if (isset($password_error)) echo $password_error; ?></span>
                            </div>
        
                            <div class="form-group">
                                <label for="name">Confirm Password</label>
                                <input type="password" name="cpassword" placeholder="Confirm Password" required class="form-control" />
                                <span class="text-danger"><?php if (isset($cpassword_error)) echo $cpassword_error; ?></span>
                            </div>
							
							<div class="form-group">
                                <label for="name">Rank</label><br />
                                <label class="radio-inline"><input name="rank" type="radio" value="Student" checked>Student</label>
								<label class="radio-inline"><input name="rank" type="radio" value="Admin">Administrator</label>
							</div>
							
							<div class="form-group">
                                <label for="name">Unique</label><br />
                                <label class="checkbox-inline"><input name="unique" type="checkbox" value="true">Unique</label>
							</div>
        
                            <div class="form-group">
                                <input type="submit" name="register" value="Register" class="btn btn-primary" />
                            </div>
                        </fieldset>
                    </form>
                    <span class="text-success"><?php if (isset($successmsg)) { echo $successmsg; } ?></span>
                    <span class="text-danger"><?php if (isset($errormsg)) { echo $errormsg; } ?></span>
                </div>
            </div>
			
        </div>
		<?php if($removeauser == true) { ?>
		<div class="container">
            <div class="row">
                <div class="col-md-4 col-md-offset-4 well">
                    <form role="form" action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post" name="removeuserform">
                        <fieldset>
                            <legend>Remove User</legend>
        
                            <div class="form-group">
								<label for="sel1">Select list:</label>
								<select class="form-control" name="userremove" id="userremove" onClick="activateremove()">
									<option selected="selected" disabled></option>
									<?php
										foreach($userlist as $k=>$v) {
									?>
										 <option value="<?php echo $userlist[$k]['username']; ?>"><?php echo $userlist[$k]["name"];?></option>
									<?php } ?>
								</select>
							</div>
        
                            <div class="form-group">
                                <input type="submit" name="remove" id="remove" value="Remove" class="btn btn-primary" disabled />
                            </div>
                        </fieldset>
                    </form>
                </div>
            </div>
			
        </div>
		<?php }  else {?>
		<div class="container">
            <div class="row">
                <div class="col-md-4 col-md-offset-4 well">
                    <form role="form" action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post" name="removeuserform">
                        <fieldset>
                            <legend>Remove A User?</legend>
        
                            <div class="form-group">
                                <input type="submit" name="removeauser" id="removeauser" value="Remove A User" class="btn btn-primary" />
                            </div>
                        </fieldset>
                    </form>
					<span class="text-success"><?php if (isset($successmsg2)) { echo $successmsg2; } ?></span>
                    <span class="text-danger"><?php if (isset($errormsg2)) { echo $errormsg2; } ?></span>
                </div>
            </div>
			
        </div>
		<?php } ?>
		<?php if($makeuniquefunc == true) { ?>
		<div class="container">
            <div class="row">
                <div class="col-md-4 col-md-offset-4 well">
                    <form role="form" action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post" name="removeuserform">
                        <fieldset>
                            <legend>Make User Unique</legend>
        
                            <div class="form-group">
								<label for="sel1">Select list:</label>
								<select class="form-control" name="unique" id="unique" onClick="activateunique()">
									<option selected="selected" disabled></option>
									<?php
										foreach($userlist as $k=>$v) {
									?>
										 <option value="<?php echo $userlist[$k]['username']; ?>"><?php echo $userlist[$k]["name"];?></option>
									<?php } ?>
								</select>
							</div>
        
                            <div class="form-group">
                                <input type="submit" name="makeunique" id="makeunique" value="Make Unique" class="btn btn-primary" disabled />
                            </div>
                        </fieldset>
                    </form>
                </div>
            </div>
			
        </div>
		<?php }  else {?>
		<div class="container">
            <div class="row">
                <div class="col-md-4 col-md-offset-4 well">
                    <form role="form" action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post" name="removeuserform">
                        <fieldset>
                            <legend>Make User Unique?</legend>
        
                            <div class="form-group">
                                <input type="submit" name="makeuniquefunc" id="makeuniquefunc" value="Make Unique" class="btn btn-primary" />
                            </div>
                        </fieldset>
                    </form>
					<span class="text-success"><?php if (isset($successmsg3)) { echo $successmsg3; } ?></span>
                    <span class="text-danger"><?php if (isset($errormsg3)) { echo $errormsg3; } ?></span>
                </div>
            </div>
			
        </div>
		<?php } ?>
	<?php } ?>
        <script src="js/jquery-1.10.2.js"></script>
        <script src="js/bootstrap.min.js"></script>
    </body>
</html>
    
